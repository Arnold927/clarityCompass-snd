

'use client';

import React, { useState, useTransition } from "react";
import { generateReportAction } from "@/app/actions";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { BotMessageSquare, Loader2 } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Label } from "../ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Textarea } from "../ui/textarea";
import { initialProjects } from "@/lib/mock-data";

const targetAudiences = [
    "Donor",
    "Executive Management",
    "Project Team",
    "Government Partners",
    "General Public"
];

export default function ReportGenerator() {
  const [selectedProject, setSelectedProject] = useState<any>(null);
  const [targetAudience, setTargetAudience] = useState("");
  const [reportContext, setReportContext] = useState("");
  const [generatedReport, setGeneratedReport] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  const handleProjectSelect = (projectId: string) => {
    const project = initialProjects.find(p => p.id === projectId);
    setSelectedProject(project || null);
  }

  // Function to synthesize project data into a string for the AI prompt
  const synthesizeProjectData = () => {
    if (!selectedProject) return "";
    
    // Using JSON.stringify for a more structured and comprehensive data representation
    const dataToSynthesize = {
      title: selectedProject.title,
      code: selectedProject.code,
      description: selectedProject.description,
      program: selectedProject.program,
      manager: selectedProject.manager,
      duration: `${selectedProject.startDate} to ${selectedProject.endDate}`,
      status: selectedProject.status,
      donors: selectedProject.donors.map((d: any) => d.name),
      financials: {
        currency: selectedProject.currency,
        totalBudget: selectedProject.tasks?.reduce((sum: number, task: any) => sum + Number(task.budget || 0), 0) || 0,
        totalSpent: selectedProject.tasks?.reduce((sum: number, task: any) => {
            return sum + (task.updates?.reduce((s: number, u: any) => s + Number(u.amountSpent || 0), 0) || 0);
        }, 0) || 0,
      },
      indicators: selectedProject.indicators?.map((ind: any) => ({
        name: ind.name,
        linkedTo: ind.linkedProgramIndicatorName,
      })),
      activities: selectedProject.activities?.map((act: any) => ({
        name: act.name,
        description: act.description,
        tasks: selectedProject.tasks?.filter((t: any) => t.activityId === act.id).map((task: any) => ({
          title: task.title,
          assignee: task.focalPersonName,
          status: task.updates?.[task.updates.length - 1]?.status || 'Not Started',
          isComplete: task.updates?.[task.updates.length - 1]?.isComplete || false,
          justification: task.updates?.[task.updates.length - 1]?.statusJustification,
        }))
      }))
    };

    return JSON.stringify(dataToSynthesize, null, 2);
  };
  
  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError(null);
    setGeneratedReport(null);

    if (!selectedProject || !targetAudience || !reportContext) {
        setError("Please select a project, a target audience, and provide a context for the report.");
        return;
    }

    startTransition(async () => {
        const projectDataString = synthesizeProjectData();
        const result = await generateReportAction({
            projectData: projectDataString,
            targetAudience,
            reportContext,
        });

        if (result.error) {
            setError(result.error);
        } else {
            setGeneratedReport(result.report);
        }
    });
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
            <form onSubmit={handleSubmit}>
                <CardHeader>
                <CardTitle>AI-Powered Reporting Engine</CardTitle>
                <CardDescription>
                    Select a project, an audience, and provide context to generate a tailored narrative report.
                </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                     <div className="space-y-2">
                        <Label htmlFor="project">Project</Label>
                        <Select onValueChange={handleProjectSelect} value={selectedProject?.id}>
                            <SelectTrigger id="project">
                                <SelectValue placeholder="Select a project..." />
                            </SelectTrigger>
                            <SelectContent>
                                {initialProjects.map(project => (
                                    <SelectItem key={project.id} value={project.id}>{project.title}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="target-audience">Target Audience</Label>
                        <Select onValueChange={setTargetAudience} value={targetAudience} disabled={!selectedProject}>
                            <SelectTrigger id="target-audience">
                                <SelectValue placeholder="Select an audience..." />
                            </SelectTrigger>
                            <SelectContent>
                                {targetAudiences.map(audience => (
                                    <SelectItem key={audience} value={audience}>{audience}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>
                     <div className="space-y-2">
                        <Label htmlFor="report-context">Report Context / Theme</Label>
                        <Textarea 
                            id="report-context"
                            placeholder="e.g., 'Focus on the challenges faced during Q3 and the mitigation strategies implemented.' or 'Highlight the project's impact on female beneficiaries.'"
                            value={reportContext}
                            onChange={(e) => setReportContext(e.target.value)}
                            rows={4}
                            disabled={!selectedProject}
                        />
                    </div>
                </CardContent>
                <CardFooter>
                    <Button type="submit" disabled={isPending || !selectedProject} className="w-full md:w-auto">
                        {isPending ? (
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        ) : (
                            <BotMessageSquare className="mr-2 h-4 w-4" />
                        )}
                        {isPending ? "Generating..." : "Generate Project Report"}
                    </Button>
                </CardFooter>
            </form>
        </Card>

        <Card className="flex flex-col">
            <CardHeader>
                <CardTitle>Generated Report</CardTitle>
                <CardDescription>
                    This is the AI-generated report. Review, copy, and edit as needed.
                </CardDescription>
            </CardHeader>
            <CardContent className="flex-grow">
                <ScrollArea className="h-96 w-full rounded-md border">
                 <div className="p-4">
                    {generatedReport ? (
                        <pre className="whitespace-pre-wrap text-sm font-sans">{generatedReport}</pre>
                    ) : (
                        <div className="flex items-center justify-center h-full text-muted-foreground">
                            <p>Your generated report will appear here.</p>
                        </div>
                    )}
                 </div>
                </ScrollArea>
                 {error && (
                    <Alert variant="destructive" className="mt-4">
                        <AlertTitle>Error</AlertTitle>
                        <AlertDescription>{error}</AlertDescription>
                    </Alert>
                )}
            </CardContent>
        </Card>
    </div>
  );
}
