
'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PlusCircle, Trash2 } from 'lucide-react';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';

interface IndicatorTargetsProps {
    indicators: any[];
    targets: any[];
    onSetTargets: (targets: any[]) => void;
}

export function IndicatorTargets({ indicators, targets, onSetTargets }: IndicatorTargetsProps) {
    const [indicatorId, setIndicatorId] = useState('');
    const [year, setYear] = useState('');
    const [quarter, setQuarter] = useState('');
    const [value, setValue] = useState('');
    const [deletingTarget, setDeletingTarget] = useState<any>(null);

    const getIndicatorName = (id: string) => {
        return indicators.find(i => i.id === id)?.name || 'Unknown Indicator';
    };

    const handleAddTarget = () => {
        if (indicatorId && year && quarter && value) {
            const newTarget = {
                id: `tgt-${Date.now()}`,
                indicatorId,
                year,
                quarter,
                value: Number(value),
            };
            onSetTargets([...targets, newTarget]);
            // Reset form
            setIndicatorId('');
            setYear('');
            setQuarter('');
            setValue('');
        }
    };
    
    const handleDeleteTarget = () => {
        if(deletingTarget) {
            onSetTargets(targets.filter(t => t.id !== deletingTarget.id));
            setDeletingTarget(null);
        }
    }

    return (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-1">
                <Card>
                    <CardHeader>
                        <CardTitle>Set New Target</CardTitle>
                        <CardDescription>Define a new quarterly target for a project indicator.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="space-y-2">
                            <Label htmlFor="indicator">Indicator</Label>
                            <Select onValueChange={setIndicatorId} value={indicatorId}>
                                <SelectTrigger id="indicator">
                                    <SelectValue placeholder="Select an indicator" />
                                </SelectTrigger>
                                <SelectContent>
                                    {indicators.map(indicator => (
                                        <SelectItem key={indicator.id} value={indicator.id}>
                                            {indicator.name}
                                        </SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="year">Financial Year</Label>
                            <Input id="year" placeholder="e.g., 2025" value={year} onChange={e => setYear(e.target.value)} />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="quarter">Quarter</Label>
                            <Select onValueChange={setQuarter} value={quarter}>
                                <SelectTrigger id="quarter">
                                    <SelectValue placeholder="Select a quarter" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="Q1">Q1 (Jan - Mar)</SelectItem>
                                    <SelectItem value="Q2">Q2 (Apr - Jun)</SelectItem>
                                    <SelectItem value="Q3">Q3 (Jul - Sep)</SelectItem>
                                    <SelectItem value="Q4">Q4 (Oct - Dec)</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="value">Target Value</Label>
                            <Input id="value" type="number" placeholder="Enter target value" value={value} onChange={e => setValue(e.target.value)} />
                        </div>
                         <Button onClick={handleAddTarget} className="w-full">
                            <PlusCircle className="mr-2 h-4 w-4" />
                            Add Target
                        </Button>
                    </CardContent>
                </Card>
            </div>
            <div className="lg:col-span-2">
                <Card>
                    <CardHeader>
                        <CardTitle>Existing Targets</CardTitle>
                        <CardDescription>A list of all defined targets for this project.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Indicator</TableHead>
                                    <TableHead>Year</TableHead>
                                    <TableHead>Quarter</TableHead>
                                    <TableHead>Target</TableHead>
                                    <TableHead className="text-right">Actions</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {targets.map(target => (
                                    <TableRow key={target.id}>
                                        <TableCell className="font-medium">{getIndicatorName(target.indicatorId)}</TableCell>
                                        <TableCell>{target.year}</TableCell>
                                        <TableCell>{target.quarter}</TableCell>
                                        <TableCell>{target.value}</TableCell>
                                        <TableCell className="text-right">
                                             <Button variant="destructive" size="icon" className="h-8 w-8" onClick={() => setDeletingTarget(target)}>
                                                <Trash2 className="h-4 w-4" />
                                            </Button>
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                        {targets.length === 0 && (
                            <p className="text-center text-muted-foreground pt-8">No targets set for this project yet.</p>
                        )}
                    </CardContent>
                </Card>
            </div>

            {deletingTarget && (
                <AlertDialog open={!!deletingTarget} onOpenChange={() => setDeletingTarget(null)}>
                <AlertDialogContent>
                    <AlertDialogHeader>
                        <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                        <AlertDialogDescription>
                            This will permanently delete the target of "{deletingTarget.value}" for {getIndicatorName(deletingTarget.indicatorId)} for {deletingTarget.quarter}, {deletingTarget.year}.
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={handleDeleteTarget} className='bg-destructive hover:bg-destructive/90'>Delete</AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
                </AlertDialog>
            )}
        </div>
    );
}

