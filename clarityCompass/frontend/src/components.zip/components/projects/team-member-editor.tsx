
'use client';

import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import type { TeamMember } from "@/lib/types";

interface TeamMemberEditorProps {
  member: TeamMember | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (member: any) => void;
  availableRoles: string[];
}

const emptyMember: Partial<TeamMember> = { name: '', role: 'VIEWER', phone: '' };

function formatRole(role: string) {
    if (role === 'M_E_OFFICER') return 'M&E Officer';
    return role.replace(/_/g, ' ');
}

export function TeamMemberEditor({
  member,
  isOpen,
  onClose,
  onSave,
  availableRoles = [],
}: TeamMemberEditorProps) {
  
  const [currentMember, setCurrentMember] = useState(member || emptyMember);

  useEffect(() => {
    setCurrentMember(member || emptyMember);
  }, [member, isOpen]);

  const handleChange = (field: string, value: string) => {
    setCurrentMember(prev => ({ ...prev, [field]: value }));
  };
  
  const handleRoleChange = (value: string) => {
    handleChange('role', value);
  };

  const handleSave = () => {
    onSave(currentMember);
  };
  
  const title = member ? "Edit Team Member" : "Add New Team Member";

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>
            {member ? "Make changes to the team member here." : "Enter the details for the new team member."}
             Click save when you're done.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="name" className="text-right">
              Name
            </Label>
            <Input
              id="name"
              value={currentMember.name}
              onChange={(e) => handleChange('name', e.target.value)}
              className="col-span-3"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="role" className="text-right">
              Role
            </Label>
             <Select onValueChange={handleRoleChange} value={currentMember.role}>
                <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Select a role" />
                </SelectTrigger>
                <SelectContent>
                    {availableRoles.map((roleName) => (
                        <SelectItem key={roleName} value={roleName}>
                            {formatRole(roleName)}
                        </SelectItem>
                    ))}
                </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="phone" className="text-right">
              Phone
            </Label>
            <Input
              id="phone"
              value={currentMember.phone}
              onChange={(e) => handleChange('phone', e.target.value)}
              className="col-span-3"
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSave}>Save Changes</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
