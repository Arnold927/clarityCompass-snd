
'use client';

import React, { useState } from 'react';
import { TaskQa } from '@/components/tasks/task-qa';
import { QaDisaggregatorEditor } from '@/components/tasks/qa-disaggregator-editor';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';

export function ProjectQaTab({ project, setProject }: { project: any, setProject: Function }) {
    const [isQaEditorOpen, setIsQaEditorOpen] = useState(false);
    const [editingQa, setEditingQa] = useState<any>(null);
    const [deletingQaAdjustment, setDeletingQaAdjustment] = useState<any>(null);

    const handleOpenQaEditor = (qaItem: any) => {
        setEditingQa(qaItem);
        setIsQaEditorOpen(true);
    };

    const handleSaveQaAdjustment = (adjustments: any) => {
        if (!editingQa) return;
        const { taskId, indicatorId } = editingQa;

        setProject((prev: any) => ({
            ...prev,
            tasks: prev.tasks.map((task: any) => {
                if (task.id === taskId) {
                    const newQaAdjustments = { ...task.qaAdjustments };
                    if (!newQaAdjustments[indicatorId]) {
                        newQaAdjustments[indicatorId] = {};
                    }

                    Object.keys(adjustments).forEach(disaggregator => {
                        newQaAdjustments[indicatorId][disaggregator] = {
                            value: adjustments[disaggregator].value,
                            justification: adjustments[disaggregator].justification
                        };
                        if (adjustments[disaggregator].value === 0 && !adjustments[disaggregator].justification) {
                            delete newQaAdjustments[indicatorId][disaggregator];
                        }
                    });

                    if (Object.keys(newQaAdjustments[indicatorId]).length === 0) {
                        delete newQaAdjustments[indicatorId];
                    }

                    return { ...task, qaAdjustments: newQaAdjustments };
                }
                return task;
            })
        }));

        setIsQaEditorOpen(false);
        setEditingQa(null);
    }

    const handleDeleteQaAdjustment = () => {
        if (!deletingQaAdjustment) return;
        const { taskId, indicatorId } = deletingQaAdjustment;

        setProject((prev: any) => ({
            ...prev,
            tasks: prev.tasks.map((task: any) => {
                if (task.id === taskId) {
                    const newAdjustments = { ...task.qaAdjustments };
                    if (newAdjustments[indicatorId]) {
                        delete newAdjustments[indicatorId];
                    }
                    return { ...task, qaAdjustments: newAdjustments };
                }
                return task;
            })
        }));

        setDeletingQaAdjustment(null);
    }

    return (
        <>
            <TaskQa
                tasks={project.tasks || []}
                indicators={project.indicators || []}
                activities={project.activities || []}
                targets={project.indicatorTargets || []}
                onAdjust={handleOpenQaEditor}
                onDelete={setDeletingQaAdjustment}
            />

            {isQaEditorOpen && editingQa && (
                <QaDisaggregatorEditor
                    isOpen={isQaEditorOpen}
                    onClose={() => { setIsQaEditorOpen(false); setEditingQa(null); }}
                    onSave={handleSaveQaAdjustment}
                    qaItem={editingQa}
                />
            )}

            {deletingQaAdjustment && (
                <AlertDialog open={!!deletingQaAdjustment} onOpenChange={() => setDeletingQaAdjustment(null)}>
                    <AlertDialogContent>
                        <AlertDialogHeader>
                            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                            <AlertDialogDescription>
                                This action cannot be undone. This will permanently delete all adjustments for indicator <strong>{deletingQaAdjustment.indicatorName}</strong> on task "{deletingQaAdjustment.taskTitle}".
                            </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={handleDeleteQaAdjustment} className='bg-destructive hover:bg-destructive/90'>Delete</AlertDialogAction>
                        </AlertDialogFooter>
                    </AlertDialogContent>
                </AlertDialog>
            )}
        </>
    );
}
