
'use client';

import React, { useState } from 'react';
import { KeyActivities } from '@/components/projects/key-activities';
import { ActivityEditor } from '@/components/projects/activity-editor';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';

export function ProjectActivitiesTab({ project, setProject }: { project: any, setProject: Function }) {
    const [isActivityEditorOpen, setIsActivityEditorOpen] = useState(false);
    const [editingActivity, setEditingActivity] = useState<any>(null);
    const [deletingActivity, setDeletingActivity] = useState<any>(null);

    const handleOpenActivityEditor = (activity: any = null) => {
        setEditingActivity(activity);
        setIsActivityEditorOpen(true);
    };

    const handleSaveActivity = (activityToSave: any) => {
        if (editingActivity) {
            setProject((prev: any) => ({
                ...prev,
                activities: prev.activities.map((act: any) => act.id === activityToSave.id ? activityToSave : act)
            }));
        } else {
            const newActivity = { ...activityToSave, id: `act-${Date.now()}` };
            setProject((prev: any) => ({ ...prev, activities: [...prev.activities, newActivity] }));
        }
        setIsActivityEditorOpen(false);
        setEditingActivity(null);
    };

    const handleDeleteActivity = () => {
        if (!deletingActivity) return;
        setProject((prev: any) => ({
            ...prev,
            activities: prev.activities.filter((act: any) => act.id !== deletingActivity.id)
        }));
        setDeletingActivity(null);
    };

    return (
        <>
            <KeyActivities
                activities={project.activities || []}
                indicators={project.indicators || []}
                onEdit={handleOpenActivityEditor}
                onDelete={setDeletingActivity}
                onAdd={() => handleOpenActivityEditor()}
            />

            {isActivityEditorOpen && (
                <ActivityEditor
                    isOpen={isActivityEditorOpen}
                    onClose={() => setIsActivityEditorOpen(false)}
                    onSave={handleSaveActivity}
                    activity={editingActivity}
                    projectIndicators={project.indicators || []}
                />
            )}

            {deletingActivity && (
                <AlertDialog open={!!deletingActivity} onOpenChange={() => setDeletingActivity(null)}>
                    <AlertDialogContent>
                        <AlertDialogHeader>
                            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                            <AlertDialogDescription>
                                This action cannot be undone. This will permanently delete the activity: "{deletingActivity.name}".
                            </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                            <AlertDialogCancel onClick={() => setDeletingActivity(null)}>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={handleDeleteActivity} className="bg-destructive hover:bg-destructive/90">Delete</AlertDialogAction>
                        </AlertDialogFooter>
                    </AlertDialogContent>
                </AlertDialog>
            )}
        </>
    );
}
