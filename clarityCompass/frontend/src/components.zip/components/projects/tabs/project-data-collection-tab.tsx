
'use client';

import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import Link from 'next/link';
import { FileText } from 'lucide-react';
import { initialDataForms } from '@/lib/mock-data';

export function ProjectDataCollectionTab({ project }: { project: any }) {
    const linkedForms = project ? initialDataForms.filter(form => form.projectIds.includes(project.id)) : [];

    return (
        <Card>
            <CardHeader>
                <CardTitle>Data Collection Forms</CardTitle>
                <CardDescription>Forms linked to this project for data collection.</CardDescription>
            </CardHeader>
            <CardContent>
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Form Title</TableHead>
                            <TableHead>Submissions</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {linkedForms.map((form) => (
                            <TableRow key={form.id}>
                                <TableCell className="font-medium">{form.title}</TableCell>
                                <TableCell>0</TableCell>
                                <TableCell className="text-right space-x-2">
                                    <Button asChild size="sm" variant="outline">
                                        <Link href={`/data-collection/submissions/${form.id}`}>
                                            View Submissions
                                        </Link>
                                    </Button>
                                    <Button asChild size="sm">
                                        <Link href={`/data-collection/entry/${form.id}`}>
                                            <FileText className="mr-2 h-4 w-4" />
                                            Enter Data
                                        </Link>
                                    </Button>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
                {linkedForms.length === 0 && (
                    <div className="text-center py-10">
                        <p className="text-muted-foreground">No data collection forms are linked to this project.</p>
                        <Button asChild variant="link" className="mt-2">
                            <Link href="/data-collection">Link a Form</Link>
                        </Button>
                    </div>
                )}
            </CardContent>
        </Card>
    );
}
