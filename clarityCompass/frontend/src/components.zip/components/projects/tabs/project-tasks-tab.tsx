

'use client';

import React, { useState } from 'react';
import { TaskCalendar } from '@/components/tasks/task-calendar';
import { TaskEditor } from '@/components/tasks/task-editor';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';

export function ProjectTasksTab({ project, setProject }: { project: any, setProject: Function }) {
    const [isTaskEditorOpen, setIsTaskEditorOpen] = useState(false);
    const [editingTask, setEditingTask] = useState<any>(null);
    const [deletingTask, setDeletingTask] = useState<any>(null);

    const handleOpenTaskEditor = (task: any = null) => {
        setEditingTask(task);
        setIsTaskEditorOpen(true);
    };

    const handleSaveTask = (taskToSave: any) => {
        if (editingTask) {
            setProject((prev: any) => ({
                ...prev,
                tasks: prev.tasks.map((t: any) => t.id === taskToSave.id ? taskToSave : t)
            }));
        } else {
            const newTask = { ...taskToSave, id: `task-${Date.now()}`, attachments: [], indicatorData: {}, updates: [], qaAdjustments: {} };
            setProject((prev: any) => ({ ...prev, tasks: [...(prev.tasks || []), newTask] }));
        }
        setIsTaskEditorOpen(false);
        setEditingTask(null);
    };

    const handleDeleteTask = () => {
        if (!deletingTask) return;
        setProject((prev: any) => ({
            ...prev,
            tasks: prev.tasks.filter((t: any) => t.id !== deletingTask.id)
        }));
        setDeletingTask(null);
    };

    return (
        <>
            <TaskCalendar
                tasks={project.tasks || []}
                locations={project.locations || []}
                onAddTask={() => handleOpenTaskEditor()}
                onEditTask={handleOpenTaskEditor}
                projectCurrency={project.currency}
            />
            {isTaskEditorOpen && (
                <TaskEditor
                    isOpen={isTaskEditorOpen}
                    onClose={() => { setIsTaskEditorOpen(false); setEditingTask(null); }}
                    onSave={handleSaveTask}
                    task={editingTask}
                    projectActivities={project.activities || []}
                    projectTeam={project.team || []}
                    projectIndicators={project.indicators || []}
                    projectLocations={project.locations || []}
                    projectCurrency={project.currency}
                />
            )}

            {deletingTask && (
                <AlertDialog open={!!deletingTask} onOpenChange={() => setDeletingTask(null)}>
                    <AlertDialogContent>
                        <AlertDialogHeader>
                            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                            <AlertDialogDescription>
                                This action cannot be undone. This will permanently delete the task: "{deletingTask.title}".
                            </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                            <AlertDialogCancel onClick={() => setDeletingTask(null)}>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={handleDeleteTask} className="bg-destructive hover:bg-destructive/90">Delete</AlertDialogAction>
                        </AlertDialogFooter>
                    </AlertDialogContent>
                </AlertDialog>
            )}
        </>
    );
}
