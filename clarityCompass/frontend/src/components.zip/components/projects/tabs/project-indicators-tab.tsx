
'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { PlusCircle, Edit, Trash2 } from 'lucide-react';
import { ProjectIndicatorEditor } from '@/components/projects/project-indicator-editor';
import { LinkProgramIndicator } from '@/components/projects/link-program-indicator';
import { DisaggregatorSelector } from '@/components/projects/disaggregator-selector';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { initialPrograms, initialStrategicPlan } from '@/lib/mock-data';

export function ProjectIndicatorsTab({ project, setProject }: { project: any, setProject: Function }) {
    const programDetails = project ? initialPrograms.find(p => p.name === project.program) || null : null;

    const [isIndicatorEditorOpen, setIsIndicatorEditorOpen] = useState(false);
    const [editingIndicator, setEditingIndicator] = useState<any>(null);
    const [isLinkerOpen, setIsLinkerOpen] = useState(false);
    const [isDisaggregatorSelectorOpen, setIsDisaggregatorSelectorOpen] = useState(false);
    const [indicatorToProcess, setIndicatorToProcess] = useState<any>(null);
    const [deletingIndicator, setDeletingIndicator] = useState<any>(null);
    const [editingDisaggregatorsFor, setEditingDisaggregatorsFor] = useState<any>(null);

    const handleOpenIndicatorEditor = (indicator: any = null) => {
        setEditingIndicator(indicator);
        setIsIndicatorEditorOpen(true);
    }

    const handleSaveIndicator = (indicatorData: { name: string, isDonorIndicator: boolean }) => {
        if (editingIndicator) {
            setProject((prev: any) => ({
                ...prev,
                indicators: prev.indicators.map((ind: any) => ind.id === editingIndicator.id ? { ...ind, ...indicatorData } : ind)
            }));
            setIsIndicatorEditorOpen(false);
            setEditingIndicator(null);
        } else {
            const newIndicator = { 
                id: `proj-ind-${Date.now()}`, 
                name: indicatorData.name, 
                isDonorIndicator: indicatorData.isDonorIndicator,
                disaggregators: [], 
                linkedProgramIndicatorName: '', 
                linkedStrategicObjectiveNumber: '' 
            };
            setIndicatorToProcess(newIndicator);
            setIsIndicatorEditorOpen(false);
            setIsLinkerOpen(true);
        }
    };

    const handleLinkProgramIndicator = (programIndicator: any) => {
        const updatedIndicator = { ...indicatorToProcess, ...programIndicator };
        setIndicatorToProcess(updatedIndicator);
        setIsLinkerOpen(false);
        setIsDisaggregatorSelectorOpen(true);
    };

    const handleSaveDisaggregators = (disaggregators: string[]) => {
        const finalIndicator = { ...indicatorToProcess, disaggregators };
        setProject((prev: any) => ({ ...prev, indicators: [...prev.indicators, finalIndicator] }));
        setIsDisaggregatorSelectorOpen(false);
        setIndicatorToProcess(null);
    };

    const handleOpenDisaggregatorEditor = (indicator: any) => {
        setEditingDisaggregatorsFor(indicator);
    }

    const handleUpdateDisaggregators = (newDisaggregators: string[]) => {
        if (!editingDisaggregatorsFor) return;
        setProject((prev: any) => ({
            ...prev,
            indicators: prev.indicators.map((ind: any) =>
                ind.id === editingDisaggregatorsFor.id
                    ? { ...ind, disaggregators: newDisaggregators }
                    : ind
            )
        }));
        setEditingDisaggregatorsFor(null);
    };

    const handleDeleteIndicator = () => {
        if (!deletingIndicator) return;
        setProject((prev: any) => ({
            ...prev,
            indicators: prev.indicators.filter((ind: any) => ind.id !== deletingIndicator.id)
        }));
        setDeletingIndicator(null);
    }

    const getAvailableProgramIndicators = () => {
        if (!programDetails) return [];

        const linkedSO_Numbers = programDetails.linkedObjectives.map((obj: any) => obj.number);
        const corporateSO_s = initialStrategicPlan.strategicObjectives.filter(so => linkedSO_Numbers.includes(so.number));

        let indicators: any[] = [];
        corporateSO_s.forEach(so => {
            const programIndicatorsForSO = programDetails.linkedObjectives.find((lo: any) => lo.number === so.number)?.indicators || [];
            programIndicatorsForSO.forEach((pi: any) => {
                indicators.push({
                    linkedProgramIndicatorName: pi.name,
                    linkedStrategicObjectiveNumber: so.number,
                    allDisaggregators: pi.disaggregators,
                });
            });
        });
        return indicators;
    };

    return (
        <>
            <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                        <CardTitle>Project Indicators</CardTitle>
                        <CardDescription>
                            Indicators specific to this project and their link to program indicators.
                        </CardDescription>
                    </div>
                    <Button onClick={() => handleOpenIndicatorEditor()}>
                        <PlusCircle className="mr-2 h-4 w-4" />
                        Add Indicator
                    </Button>
                </CardHeader>
                <CardContent>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Project Indicator</TableHead>
                                <TableHead>Disaggregators</TableHead>
                                <TableHead>Linked Program Indicator</TableHead>
                                <TableHead>Strategic Objective</TableHead>
                                <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {project.indicators.map((indicator: any) => (
                                <TableRow key={indicator.id}>
                                    <TableCell className="font-medium">
                                        <div className="flex items-center gap-2">
                                            <span>{indicator.name}</span>
                                            {indicator.isDonorIndicator && <Badge>Donor</Badge>}
                                        </div>
                                    </TableCell>
                                    <TableCell>
                                        <div className="flex flex-wrap gap-1">
                                            {indicator.disaggregators.map((d: string) => (
                                                <Badge key={d} variant="outline" className="font-normal">{d}</Badge>
                                            ))}
                                        </div>
                                    </TableCell>
                                    <TableCell>{indicator.linkedProgramIndicatorName}</TableCell>
                                    <TableCell>
                                        <Badge variant="secondary">{indicator.linkedStrategicObjectiveNumber}</Badge>
                                    </TableCell>
                                    <TableCell className="text-right space-x-1">
                                        <Button variant="outline" size="sm" onClick={() => handleOpenDisaggregatorEditor(indicator)}>
                                            Edit Disaggregators
                                        </Button>
                                        <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => handleOpenIndicatorEditor(indicator)}>
                                            <Edit className="h-4 w-4" />
                                        </Button>
                                        <Button variant="destructive" size="icon" className="h-8 w-8" onClick={() => setDeletingIndicator(indicator)}>
                                            <Trash2 className="h-4 w-4" />
                                        </Button>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                    {project.indicators.length === 0 && (
                        <p className="text-muted-foreground text-center mt-4">No project-specific indicators defined yet.</p>
                    )}
                </CardContent>
            </Card>

            {isIndicatorEditorOpen && (
                <ProjectIndicatorEditor
                    indicator={editingIndicator}
                    isOpen={isIndicatorEditorOpen}
                    onClose={() => { setIsIndicatorEditorOpen(false); setEditingIndicator(null); }}
                    onSave={handleSaveIndicator}
                />
            )}

            {isLinkerOpen && indicatorToProcess && (
                <LinkProgramIndicator
                    isOpen={isLinkerOpen}
                    onClose={() => { setIsLinkerOpen(false); setIndicatorToProcess(null); }}
                    onLink={handleLinkProgramIndicator}
                    availableIndicators={getAvailableProgramIndicators()}
                />
            )}

            {isDisaggregatorSelectorOpen && indicatorToProcess && (
                <DisaggregatorSelector
                    isOpen={isDisaggregatorSelectorOpen}
                    onClose={() => { setIsDisaggregatorSelectorOpen(false); setIndicatorToProcess(null); }}
                    onSave={handleSaveDisaggregators}
                    availableDisaggregators={indicatorToProcess.allDisaggregators || []}
                    selectedDisaggregators={indicatorToProcess.disaggregators}
                />
            )}

            {editingDisaggregatorsFor && (
                <DisaggregatorSelector
                    isOpen={!!editingDisaggregatorsFor}
                    onClose={() => setEditingDisaggregatorsFor(null)}
                    onSave={handleUpdateDisaggregators}
                    availableDisaggregators={editingDisaggregatorsFor.allDisaggregators || []}
                    selectedDisaggregators={editingDisaggregatorsFor.disaggregators}
                />
            )}

            {deletingIndicator && (
                <AlertDialog open={!!deletingIndicator} onOpenChange={() => setDeletingIndicator(null)}>
                    <AlertDialogContent>
                        <AlertDialogHeader>
                            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                            <AlertDialogDescription>
                                This action cannot be undone. This will permanently delete the indicator: "{deletingIndicator.name}".
                            </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                            <AlertDialogCancel onClick={() => setDeletingIndicator(null)}>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={handleDeleteIndicator} className="bg-destructive hover:bg-destructive/90">Delete</AlertDialogAction>
                        </AlertDialogFooter>
                    </AlertDialogContent>
                </AlertDialog>
            )}
        </>
    );
}
