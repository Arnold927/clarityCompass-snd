
'use client';

import React from 'react';
import { IndicatorTargets } from '@/components/projects/indicator-targets';

export function ProjectTargetsTab({ project, setProject }: { project: any, setProject: Function }) {
    const handleSetIndicatorTargets = (targets: any[]) => {
        setProject((prev: any) => ({ ...prev, indicatorTargets: targets }));
    };

    return (
        <IndicatorTargets
            indicators={project.indicators || []}
            targets={project.indicatorTargets || []}
            onSetTargets={handleSetIndicatorTargets}
        />
    );
}
