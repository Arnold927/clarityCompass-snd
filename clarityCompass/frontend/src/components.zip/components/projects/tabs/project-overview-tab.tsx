
'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from '@/components/ui/badge';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { PlusCircle, Edit, Trash2, MapPin } from 'lucide-react';
import { TeamManagement } from '@/components/projects/team-management';
import { LocationEditor } from '@/components/projects/location-editor';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';

export function ProjectOverviewTab({ project, setProject }: { project: any, setProject: Function }) {
    
    // Location Management State
    const [isLocationEditorOpen, setIsLocationEditorOpen] = useState(false);
    const [editingLocation, setEditingLocation] = useState<any>(null);
    const [deletingLocation, setDeletingLocation] = useState<any>(null);

    const handleSetTeamMembers = (newTeam: any[]) => {
        setProject((prev: any) => ({ ...prev, team: newTeam }));
    };

    // Location Handlers
    const handleOpenLocationEditor = (location: any = null) => {
        setEditingLocation(location);
        setIsLocationEditorOpen(true);
    }

    const handleSaveLocation = (locationToSave: any) => {
        if (editingLocation) {
            setProject((prev: any) => ({
                ...prev,
                locations: prev.locations.map((loc: any) => loc.id === locationToSave.id ? locationToSave : loc)
            }));
        } else {
            const newLocation = { ...locationToSave, id: `loc-${Date.now()}` };
            setProject((prev: any) => ({ ...prev, locations: [...(prev.locations || []), newLocation] }));
        }
        setIsLocationEditorOpen(false);
        setEditingLocation(null);
    }

    const handleDeleteLocation = () => {
        if (!deletingLocation) return;
        setProject((prev: any) => ({
            ...prev,
            locations: prev.locations.filter((loc: any) => loc.id !== deletingLocation.id)
        }));
        setDeletingLocation(null);
    }

    return (
        <>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <Card>
                    <CardHeader>
                        <CardTitle>Project Details</CardTitle>
                        <CardDescription>{project.description}</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className='grid grid-cols-2 gap-4'>
                            <div><strong>Program:</strong> <Link href={`/programs`} className='text-primary hover:underline'>{project.program}</Link></div>
                            <div><strong>Project Manager:</strong> {project.manager}</div>
                            <div><strong>Duration:</strong> {project.startDate} to {project.endDate}</div>
                            <div><strong>Standard Currency:</strong> {project.currency}</div>
                            <div><strong>Status:</strong> <Badge variant={project.status === 'On Track' ? 'default' : 'destructive'}>{project.status}</Badge></div>
                        </div>
                        <div>
                            <h4 className="font-semibold mb-2 mt-4">Donors</h4>
                            <div className="flex flex-wrap gap-2">
                                {project.donors.map((donor: any) => (
                                    <Badge key={donor.id} variant="secondary">{donor.name}</Badge>
                                ))}
                            </div>
                        </div>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between">
                        <div>
                            <CardTitle>Implementation Locations</CardTitle>
                            <CardDescription>Geographic areas where this project is active.</CardDescription>
                        </div>
                        <Button variant="outline" size="sm" onClick={() => handleOpenLocationEditor()}>
                            <PlusCircle className="mr-2 h-4 w-4" /> Add Location
                        </Button>
                    </CardHeader>
                    <CardContent>
                        {project.locations && project.locations.length > 0 ? (
                            <ul className="space-y-1">
                                {project.locations.map((loc: any) => (
                                    <li key={loc.id} className="flex items-center justify-between group p-2 rounded-md hover:bg-muted">
                                        <div className="flex items-center gap-2">
                                            <MapPin className="h-4 w-4 text-muted-foreground" />
                                            <span className="text-sm text-muted-foreground">{loc.name}</span>
                                        </div>
                                        <div className="opacity-0 group-hover:opacity-100 transition-opacity space-x-1">
                                            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => handleOpenLocationEditor(loc)}>
                                                <Edit className="h-4 w-4" />
                                            </Button>
                                            <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => setDeletingLocation(loc)}>
                                                <Trash2 className="h-4 w-4" />
                                            </Button>
                                        </div>
                                    </li>
                                ))}
                            </ul>
                        ) : (
                            <p className="text-sm text-muted-foreground text-center py-8">No implementation locations defined for this project.</p>
                        )}
                    </CardContent>
                </Card>
            </div>
            <TeamManagement
                teamMembers={project.team || []}
                setTeamMembers={handleSetTeamMembers}
                projectManager={project.manager}
            />

            {isLocationEditorOpen && (
                <LocationEditor
                    location={editingLocation}
                    isOpen={isLocationEditorOpen}
                    onClose={() => { setIsLocationEditorOpen(false); setEditingLocation(null); }}
                    onSave={handleSaveLocation}
                />
            )}

            {deletingLocation && (
                <AlertDialog open={!!deletingLocation} onOpenChange={() => setDeletingLocation(null)}>
                    <AlertDialogContent>
                        <AlertDialogHeader>
                            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                            <AlertDialogDescription>
                                This will permanently delete the location: "{deletingLocation.name}".
                            </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={handleDeleteLocation} className="bg-destructive hover:bg-destructive/90">Delete</AlertDialogAction>
                        </AlertDialogFooter>
                    </AlertDialogContent>
                </AlertDialog>
            )}
        </>
    );
}
