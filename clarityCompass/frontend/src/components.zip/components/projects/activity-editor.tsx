
'use client';

import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface ActivityEditorProps {
  activity: any | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (activity: any) => void;
  projectIndicators: any[];
}

const emptyActivity = { id: null, name: '', description: '', linkedIndicatorId: '' };

export function ActivityEditor({
  activity,
  isOpen,
  onClose,
  onSave,
  projectIndicators,
}: ActivityEditorProps) {
  const [currentActivity, setCurrentActivity] = useState(activity || emptyActivity);

  useEffect(() => {
    setCurrentActivity(activity || emptyActivity);
  }, [activity, isOpen]);

  const handleChange = (field: string, value: string) => {
    setCurrentActivity(prev => ({ ...prev, [field]: value }));
  };

  const handleIndicatorChange = (value: string) => {
    handleChange('linkedIndicatorId', value);
  };

  const handleSave = () => {
    if (currentActivity.name && currentActivity.description && currentActivity.linkedIndicatorId) {
        onSave(currentActivity);
    }
  };
  
  const title = activity ? "Edit Activity" : "Create New Activity";

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>
            {activity ? "Make changes to your activity." : "Enter the details for the new activity."} Click save when you're done.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="name" className="text-right">
              Name
            </Label>
            <Input
              id="name"
              value={currentActivity.name}
              onChange={(e) => handleChange('name', e.target.value)}
              className="col-span-3"
            />
          </div>
          <div className="grid grid-cols-4 items-start gap-4">
            <Label htmlFor="description" className="text-right pt-2">
              Description
            </Label>
            <Textarea
              id="description"
              value={currentActivity.description}
              onChange={(e) => handleChange('description', e.target.value)}
              className="col-span-3"
              rows={4}
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="linkedIndicatorId" className="text-right">
              Indicator
            </Label>
            <Select onValueChange={handleIndicatorChange} value={currentActivity.linkedIndicatorId}>
                <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Select an indicator to link" />
                </SelectTrigger>
                <SelectContent>
                    {projectIndicators.map((indicator) => (
                        <SelectItem key={indicator.id} value={indicator.id}>
                            {indicator.name}
                        </SelectItem>
                    ))}
                </SelectContent>
            </Select>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSave}>Save Changes</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
