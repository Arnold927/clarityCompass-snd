

'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableRow } from '@/components/ui/table';
import { PlusCircle, Edit, Trash2, ChevronDown, ChevronRight, Target, Goal } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { OutcomeEditor } from '@/components/strategic-plan/outcome-editor';
import { OutputEditor } from '@/components/strategic-plan/output-editor';
import { IndicatorEditor } from '@/components/strategic-plan/indicator-editor';
import { Input } from '../ui/input';
import { ActivityEditor } from '../strategic-plan/activity-editor';

export function ProjectResultsFramework({ project, setProject }: { project: any, setProject: Function }) {
    
    const [framework, setFramework] = useState(project.resultsFramework || { objective: '', outcomes: [] });
    const [editingObjective, setEditingObjective] = useState(false);

    const [openOutcomes, setOpenOutcomes] = useState<string[]>(framework.outcomes.map((o: any) => o.id));

    // Editing State
    const [editingOutcome, setEditingOutcome] = useState<any>(null);
    const [editingOutput, setEditingOutput] = useState<any>(null);
    const [editingActivity, setEditingActivity] = useState<any>(null);
    const [editingIndicator, setEditingIndicator] = useState<{value: string, parent: any} | null>(null);

    // Parent context for adding new items
    const [parentOutcome, setParentOutcome] = useState<any>(null);
    const [parentOutput, setParentOutput] = useState<any>(null);
    const [parentForIndicator, setParentForIndicator] = useState<any>(null);


    // Deleting State
    const [deletingItem, setDeletingItem] = useState<any>(null);
    
    const toggleOutcome = (id: string) => {
        setOpenOutcomes(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
    };
    
    const updateFramework = (newFramework: any) => {
        setFramework(newFramework);
        setProject({...project, resultsFramework: newFramework });
    }

    const handleObjectiveChange = (value: string) => {
        updateFramework({...framework, objective: value});
    }

    const handleSaveOutcome = (outcomeToSave: any) => {
        let newOutcomes;
        if (outcomeToSave.id) { // Editing
             newOutcomes = framework.outcomes.map((o: any) => o.id === outcomeToSave.id ? outcomeToSave : o);
        } else { // Adding
            const newOutcome = { ...outcomeToSave, id: `prj-outcome-${Date.now()}`, outputs: [], indicators: [] };
            newOutcomes = [...framework.outcomes, newOutcome];
        }
        updateFramework({...framework, outcomes: newOutcomes});
        setEditingOutcome(null);
    }

    const handleSaveOutput = (outputToSave: any) => {
        let newOutcomes = framework.outcomes.map((o: any) => {
            if (o.id === parentOutcome.id) {
                let newOutputs;
                 if (outputToSave.id) { // Editing
                    newOutputs = o.outputs.map((op: any) => op.id === outputToSave.id ? outputToSave : op);
                } else { // Adding
                    const newOutput = { ...outputToSave, id: `prj-output-${Date.now()}`, indicators: [], activities: [] };
                    newOutputs = [...o.outputs, newOutput];
                }
                return { ...o, outputs: newOutputs };
            }
            return o;
        });
        updateFramework({...framework, outcomes: newOutcomes});
        setEditingOutput(null);
        setParentOutcome(null);
    }
    
    const handleSaveActivity = (activityToSave: any) => {
        let newOutcomes = framework.outcomes.map((o: any) => ({
            ...o,
            outputs: o.outputs.map((op: any) => {
                if (op.id === parentOutput.id) {
                    let newActivities;
                    if(activityToSave.id){
                        newActivities = op.activities.map((act: any) => act.id === activityToSave.id ? activityToSave : act);
                    } else {
                        const newActivity = { ...activityToSave, id: `prj-act-${Date.now()}`};
                        newActivities = [...op.activities, newActivity];
                    }
                    return {...op, activities: newActivities};
                }
                return op;
            })
        }));
        updateFramework({...framework, outcomes: newOutcomes});
        setEditingActivity(null);
        setParentOutput(null);
    }


    const handleSaveIndicator = (indicatorValue: string) => {
        if (!parentForIndicator && !editingIndicator) return;
        
        const { parent, type, index } = editingIndicator ? editingIndicator.parent : parentForIndicator;
        const isEditing = editingIndicator !== null;

        const updateIndicators = (indicators: any[]) => {
            const newIndicators = [...(indicators || [])];
            if (isEditing) {
                newIndicators[index] = { ...newIndicators[index], name: indicatorValue };
            } else {
                newIndicators.push({ name: indicatorValue, disaggregators: [] });
            }
            return newIndicators;
        };

        const updatedOutcomes = framework.outcomes.map((o: any) => {
            if (type === 'outcome' && o.id === parent.id) {
                return { ...o, indicators: updateIndicators(o.indicators) }
            }
            if (type === 'output') {
                return {
                    ...o,
                    outputs: o.outputs.map((op: any) => {
                        if (op.id === parent.id) {
                            return { ...op, indicators: updateIndicators(op.indicators) };
                        }
                        return op;
                    })
                };
            }
            return o;
        });
        updateFramework({ ...framework, outcomes: updatedOutcomes });

        setEditingIndicator(null);
        setParentForIndicator(null);
    };

    const confirmDelete = () => {
        if (!deletingItem) return;
        
        const { type, id, parentId, grandParentId, index } = deletingItem;
        
        let newOutcomes = [...framework.outcomes];

        if (type === 'outcome') {
            newOutcomes = newOutcomes.filter((o:any) => o.id !== id);
        } else if (type === 'output') {
             newOutcomes = newOutcomes.map((o:any) => o.id === parentId ? { ...o, outputs: o.outputs.filter((op:any) => op.id !== id)} : o);
        } else if (type === 'activity') {
            newOutcomes = newOutcomes.map((o: any) => o.id === grandParentId ? { ...o, outputs: o.outputs.map((op: any) => op.id === parentId ? { ...op, activities: op.activities.filter((act: any) => act.id !== id) } : op) } : o );
        } else if (type === 'indicator') {
            newOutcomes = newOutcomes.map((o: any) => {
                if (deletingItem.indicatorType === 'outcome' && o.id === parentId) {
                    const newIndicators = [...o.indicators];
                    newIndicators.splice(index, 1);
                    return {...o, indicators: newIndicators};
                }
                if (deletingItem.indicatorType === 'output' && o.id === grandParentId) {
                    return {
                        ...o,
                        outputs: o.outputs.map((op: any) => {
                            if (op.id === parentId) {
                                const newIndicators = [...op.indicators];
                                newIndicators.splice(index, 1);
                                return { ...op, indicators: newIndicators };
                            }
                            return op;
                        })
                    };
                }
                return o;
            });
        }
        
        updateFramework({ ...framework, outcomes: newOutcomes });
        setDeletingItem(null);
    };
    
    const getIndicatorTitle = () => {
        if (!editingIndicator && !parentForIndicator) return "Add New Indicator";
        if (editingIndicator?.value) return "Edit Indicator";
        
        const { parent, type } = parentForIndicator || editingIndicator.parent;
        return `Add Indicator for ${type === 'outcome' ? 'Outcome' : 'Output'}: ${parent.name}`;
    }

    return (
        <>
            <Card>
                <CardHeader>
                    <CardTitle>Project Results Framework</CardTitle>
                    <CardDescription>
                        Define the independent results framework for this project, from its objective down to key activities.
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="p-4 border-l-4 border-primary bg-primary/10 rounded-r-lg space-y-2">
                        <div className="flex items-center justify-between">
                            <h3 className="text-lg font-bold text-primary flex items-center gap-3">
                                <Goal className="h-6 w-6" />
                                Project Objective
                            </h3>
                            <Button variant="ghost" size="sm" onClick={() => setEditingObjective(!editingObjective)}>
                                <Edit className="mr-2 h-4 w-4" />
                                {editingObjective ? 'Done' : 'Edit'}
                            </Button>
                        </div>
                        {editingObjective ? (
                             <Input 
                                value={framework.objective} 
                                onChange={(e) => handleObjectiveChange(e.target.value)}
                                placeholder="Define the overall project objective..."
                            />
                        ) : (
                             <p className="text-sm text-primary/80 pl-9">{framework.objective || "Not defined"}</p>
                        )}
                    </div>
                     <div className="mt-4 flex justify-end">
                        <Button onClick={() => setEditingOutcome({})}>
                            <PlusCircle className="mr-2 h-4 w-4" />
                            Add Outcome
                        </Button>
                    </div>

                    <Table className="mt-2">
                        <TableBody>
                            {framework.outcomes.map((outcome: any) => (
                                <React.Fragment key={outcome.id}>
                                    <TableRow className="bg-muted/50 hover:bg-muted/50">
                                        <TableCell colSpan={3} className="font-bold">
                                            <div className="flex items-center gap-2">
                                                <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => toggleOutcome(outcome.id)}>
                                                    {openOutcomes.includes(outcome.id) ? <ChevronDown className="h-5 w-5" /> : <ChevronRight className="h-5 w-5" />}
                                                </Button>
                                                <Target className="h-5 w-5 text-accent-foreground" />
                                                {outcome.name}
                                            </div>
                                        </TableCell>
                                        <TableCell className="text-right">
                                            <Button variant="outline" size="sm" onClick={() => setEditingOutcome(outcome)}>
                                                <Edit className="mr-2 h-4 w-4" /> Edit
                                            </Button>
                                             <Button variant="destructive" size="sm" className="ml-2" onClick={() => setDeletingItem({ type: 'outcome', name: outcome.name, id: outcome.id })}>
                                                <Trash2 className="mr-2 h-4 w-4" /> Delete
                                            </Button>
                                        </TableCell>
                                    </TableRow>

                                    {openOutcomes.includes(outcome.id) && (
                                        <>
                                            {(outcome.indicators || []).map((indicator: any, index: number) => (
                                                <TableRow key={index}>
                                                    <TableCell className="pl-24 text-sm text-muted-foreground">{indicator.name}</TableCell>
                                                    <TableCell><Badge variant="ghost">Indicator</Badge></TableCell>
                                                    <TableCell></TableCell>
                                                    <TableCell className="text-right space-x-2">
                                                        <Button variant="ghost" size="sm" onClick={() => setEditingIndicator({value: indicator.name, parent: {parent: outcome, type: 'outcome', index}})}>Edit</Button>
                                                        <Button variant="ghost" size="sm" className="text-red-600" onClick={() => setDeletingItem({ type: 'indicator', indicatorType: 'outcome', name: indicator.name, index, parentId: outcome.id })}>Delete</Button>
                                                    </TableCell>
                                                </TableRow>
                                            ))}
                                            <TableRow>
                                                <TableCell colSpan={4} className="pl-24 py-1">
                                                    <Button variant="ghost" size="sm" className="w-full justify-start text-muted-foreground" onClick={() => { setParentForIndicator({ parent: outcome, type: 'outcome' }); setEditingIndicator({value: '', parent: null}); }}>
                                                        <PlusCircle className="mr-2 h-4 w-4" /> Add Outcome Indicator
                                                    </Button>
                                                </TableCell>
                                            </TableRow>

                                            {outcome.outputs.map((output: any) => (
                                                <React.Fragment key={output.id}>
                                                    <TableRow>
                                                        <TableCell className="pl-24">{output.name}</TableCell>
                                                        <TableCell><Badge variant="outline">Output</Badge></TableCell>
                                                        <TableCell>{output.indicators?.length || 0} ind. / {output.activities?.length || 0} act.</TableCell>
                                                        <TableCell className="text-right space-x-2">
                                                            <Button variant="ghost" size="sm" onClick={() => { setParentOutcome(outcome); setEditingOutput(output); }}>Edit</Button>
                                                            <Button variant="ghost" size="sm" className="text-red-600" onClick={() => setDeletingItem({ type: 'output', name: output.name, id: output.id, parentId: outcome.id })}>Delete</Button>
                                                        </TableCell>
                                                    </TableRow>
                                                    
                                                     {(output.indicators || []).map((indicator: any, index: number) => (
                                                        <TableRow key={`ind-${index}`}>
                                                            <TableCell className="pl-32 text-sm text-muted-foreground">{indicator.name}</TableCell>
                                                            <TableCell><Badge variant="ghost">Indicator</Badge></TableCell>
                                                            <TableCell></TableCell>
                                                            <TableCell className="text-right space-x-2">
                                                                <Button variant="ghost" size="sm" onClick={() => setEditingIndicator({value: indicator.name, parent: {parent: output, type: 'output', index}})}>Edit</Button>
                                                                <Button variant="ghost" size="sm" className="text-red-600" onClick={() => setDeletingItem({ type: 'indicator', indicatorType: 'output', name: indicator.name, index, parentId: output.id, grandParentId: outcome.id })}>Delete</Button>
                                                            </TableCell>
                                                        </TableRow>
                                                    ))}
                                                     <TableRow>
                                                        <TableCell colSpan={4} className="pl-32 py-1">
                                                            <Button variant="ghost" size="sm" className="w-full justify-start text-muted-foreground" onClick={() => { setParentForIndicator({ parent: output, type: 'output' }); setEditingIndicator({value: '', parent: null}); }}>
                                                                <PlusCircle className="mr-2 h-4 w-4" /> Add Output Indicator
                                                            </Button>
                                                        </TableCell>
                                                    </TableRow>
                                                    {(output.activities || []).map((activity: any) => (
                                                        <TableRow key={activity.id}>
                                                            <TableCell className="pl-32 text-sm text-muted-foreground">{activity.name}</TableCell>
                                                            <TableCell><Badge variant="ghost">Activity</Badge></TableCell>
                                                            <TableCell></TableCell>
                                                            <TableCell className="text-right space-x-2">
                                                                <Button variant="ghost" size="sm" onClick={() => { setParentOutput(output); setEditingActivity(activity)}}>Edit</Button>
                                                                <Button variant="ghost" size="sm" className="text-red-600" onClick={() => setDeletingItem({ type: 'activity', name: activity.name, id: activity.id, parentId: output.id, grandParentId: outcome.id })}>Delete</Button>
                                                            </TableCell>
                                                        </TableRow>
                                                    ))}
                                                    <TableRow>
                                                        <TableCell colSpan={4} className="pl-32 py-1">
                                                            <Button variant="ghost" size="sm" className="w-full justify-start text-muted-foreground" onClick={() => { setParentOutput(output); setEditingActivity({});}}>
                                                                <PlusCircle className="mr-2 h-4 w-4" /> Add Key Activity
                                                            </Button>
                                                        </TableCell>
                                                    </TableRow>

                                                </React.Fragment>
                                            ))}
                                            <TableRow>
                                                <TableCell colSpan={4} className="pl-24">
                                                    <Button variant="secondary" size="sm" onClick={() => { setParentOutcome(outcome); setEditingOutput({}); }}>
                                                        <PlusCircle className="mr-2 h-4 w-4" /> Add Output
                                                    </Button>
                                                </TableCell>
                                            </TableRow>
                                        </>
                                    )}
                                </React.Fragment>
                            ))}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>

            {editingOutcome && (
                <OutcomeEditor
                    outcome={editingOutcome}
                    isOpen={!!editingOutcome}
                    onClose={() => setEditingOutcome(null)}
                    onSave={handleSaveOutcome}
                />
            )}
            {editingOutput && (
                <OutputEditor
                    output={editingOutput}
                    isOpen={!!editingOutput}
                    onClose={() => setEditingOutput(null)}
                    onSave={handleSaveOutput}
                />
            )}
            {editingActivity && (
                <ActivityEditor
                    activity={editingActivity}
                    isOpen={!!editingActivity}
                    onClose={() => setEditingActivity(null)}
                    onSave={handleSaveActivity}
                />
            )}
            {editingIndicator !== null && (
                <IndicatorEditor
                    indicator={editingIndicator.value}
                    isOpen={editingIndicator !== null}
                    onClose={() => {setEditingIndicator(null); setParentForIndicator(null);}}
                    onSave={handleSaveIndicator}
                    title={getIndicatorTitle()}
                />
            )}

            {deletingItem && (
                <AlertDialog open={!!deletingItem} onOpenChange={() => setDeletingItem(null)}>
                    <AlertDialogContent>
                        <AlertDialogHeader>
                            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                            <AlertDialogDescription>
                                This action cannot be undone. This will permanently delete the {deletingItem.type} "{deletingItem.name}" and all its children.
                            </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={confirmDelete} className="bg-destructive hover:bg-destructive/90">Delete</AlertDialogAction>
                        </AlertDialogFooter>
                    </AlertDialogContent>
                </AlertDialog>
            )}
        </>
    );
}
