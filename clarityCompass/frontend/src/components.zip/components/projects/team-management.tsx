
'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Edit, PlusCircle, Trash2 } from 'lucide-react';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { TeamMemberEditor } from './team-member-editor';
import { projectRoles } from '@/lib/mock-data';
import type { TeamMember } from '@/lib/types';

function formatRole(role: string) {
    if (role === 'M_E_OFFICER') return 'M&E Officer';
    return role.replace(/_/g, ' ');
}

export function TeamManagement({ teamMembers, setTeamMembers, projectManager }: { teamMembers: TeamMember[], setTeamMembers: Function, projectManager?: string }) {
    const [isEditorOpen, setIsEditorOpen] = useState(false);
    const [editingMember, setEditingMember] = useState<any>(null);
    const [deletingMember, setDeletingMember] = useState<any>(null);

    const handleSaveMember = (memberToSave: TeamMember) => {
        let updatedTeam = [...teamMembers];

        // If making a member the new PM, demote the old one
        if (memberToSave.role === 'PROJECT_MANAGER' && projectManager && memberToSave.name !== projectManager) {
            updatedTeam = updatedTeam.map(m => m.name === projectManager ? { ...m, role: 'VIEWER' } : m);
        }
        
        const existingIndex = updatedTeam.findIndex(m => m.id === memberToSave.id);
        if (existingIndex > -1) {
            updatedTeam[existingIndex] = memberToSave;
        } else {
            const newMember = { ...memberToSave, id: `usr-new-${Date.now()}` };
            updatedTeam.push(newMember);
        }

        setTeamMembers(updatedTeam);
        setIsEditorOpen(false);
        setEditingMember(null);
    };

    const handleDeleteMember = () => {
        if (deletingMember) {
            setTeamMembers(teamMembers.filter(m => m.id !== deletingMember.id));
            setDeletingMember(null);
        }
    };

    const handleOpenEditor = (member: any = null) => {
        setEditingMember(member);
        setIsEditorOpen(true);
    };

    return (
        <>
            <Card>
                <CardHeader className='flex-row items-center justify-between'>
                    <div>
                        <CardTitle>Project Team</CardTitle>
                        <CardDescription>Manage project team members and their roles.</CardDescription>
                    </div>
                    <Button onClick={() => handleOpenEditor()}>
                        <PlusCircle className="mr-2 h-4 w-4" />
                        Add Member
                    </Button>
                </CardHeader>
                <CardContent>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Name</TableHead>
                                <TableHead>Role</TableHead>
                                <TableHead>Phone Number</TableHead>
                                <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {teamMembers.map((member) => (
                                <TableRow key={member.id}>
                                    <TableCell>{member.name}</TableCell>
                                    <TableCell>{formatRole(member.role)}</TableCell>
                                    <TableCell>{member.phone}</TableCell>
                                    <TableCell className="text-right space-x-2">
                                        <Button variant="outline" size="icon" className="h-9 w-9" onClick={() => handleOpenEditor(member)}>
                                            <Edit className="h-4 w-4" />
                                        </Button>
                                        <Button variant="destructive" size="icon" className="h-9 w-9" onClick={() => setDeletingMember(member)} disabled={member.name === projectManager}>
                                            <Trash2 className="h-4 w-4" />
                                        </Button>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>

            {(isEditorOpen || editingMember) && (
                <TeamMemberEditor
                    isOpen={isEditorOpen}
                    onClose={() => { setIsEditorOpen(false); setEditingMember(null); }}
                    onSave={handleSaveMember}
                    member={editingMember}
                    availableRoles={projectRoles}
                />
            )}

            {deletingMember && (
                <AlertDialog open={!!deletingMember} onOpenChange={() => setDeletingMember(null)}>
                <AlertDialogContent>
                    <AlertDialogHeader>
                    <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                    <AlertDialogDescription>
                        This action cannot be undone. This will permanently delete the team member: "{deletingMember.name}".
                    </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={handleDeleteMember} className='bg-destructive hover:bg-destructive/90'>Delete</AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
                </AlertDialog>
            )}
        </>
    );
}
