
'use client';

import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Edit, PlusCircle, Trash2 } from 'lucide-react';
import { Badge } from '../ui/badge';

interface KeyActivitiesProps {
    activities: any[];
    indicators: any[];
    onAdd: () => void;
    onEdit: (activity: any) => void;
    onDelete: (activity: any) => void;
}

export function KeyActivities({ activities, indicators, onAdd, onEdit, onDelete }: KeyActivitiesProps) {
    const getIndicatorName = (indicatorId: string) => {
        const indicator = indicators.find(i => i.id === indicatorId);
        return indicator ? indicator.name : 'N/A';
    };

    return (
        <Card>
            <CardHeader className='flex-row items-center justify-between'>
                <div>
                    <CardTitle>Key Activities</CardTitle>
                    <CardDescription>The main activities planned for this project.</CardDescription>
                </div>
                <Button onClick={onAdd}>
                    <PlusCircle className="mr-2 h-4 w-4" />
                    Add Activity
                </Button>
            </CardHeader>
            <CardContent>
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead className="w-1/3">Activity</TableHead>
                            <TableHead className="w-1/3">Linked Indicator</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {activities.map((activity) => (
                            <TableRow key={activity.id}>
                                <TableCell>
                                    <p className="font-medium">{activity.name}</p>
                                    <p className="text-sm text-muted-foreground">{activity.description}</p>
                                </TableCell>
                                <TableCell>
                                    <Badge variant="outline" className="font-normal">{getIndicatorName(activity.linkedIndicatorId)}</Badge>
                                </TableCell>
                                <TableCell className="text-right space-x-2">
                                    <Button variant="outline" size="icon" className="h-9 w-9" onClick={() => onEdit(activity)}>
                                        <Edit className="h-4 w-4" />
                                    </Button>
                                    <Button variant="destructive" size="icon" className="h-9 w-9" onClick={() => onDelete(activity)}>
                                        <Trash2 className="h-4 w-4" />
                                    </Button>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
                {activities.length === 0 && (
                    <p className="text-center text-muted-foreground mt-4">No activities defined yet.</p>
                )}
            </CardContent>
        </Card>
    );
}
