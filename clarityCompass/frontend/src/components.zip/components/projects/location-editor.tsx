

'use client';

import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "../ui/input";

interface LocationEditorProps {
  location: { id: string; name: string; } | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (location: any) => void;
}

const emptyLocation = { name: '' };

export function LocationEditor({
  location,
  isOpen,
  onClose,
  onSave,
}: LocationEditorProps) {
  const [currentLocation, setCurrentLocation] = useState<any>(location || emptyLocation);

  useEffect(() => {
    setCurrentLocation(location || emptyLocation);
  }, [location, isOpen]);

  const handleSave = () => {
    if (currentLocation && currentLocation.name) {
      onSave(currentLocation);
    }
  };
  
  const handleChange = (field: string, value: any) => {
    setCurrentLocation((prev: any) => ({ ...prev, [field]: value }));
  };

  const title = location?.id ? "Edit Location" : "Add New Location";

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>
            {location ? "Make changes to the implementation location." : "Enter the name of the new location."}
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="name">Location Name</Label>
            <Input
                id="name"
                placeholder="e.g., Kibera, Nairobi"
                value={currentLocation.name}
                onChange={(e) => handleChange('name', e.target.value)}
              />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSave} disabled={!currentLocation.name}>Save Location</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
