import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import type { TeamMember } from "@/lib/types";


interface ProjectEditorProps {
  project: {
    id: string;
    code: string;
    title: string;
    program: any; // Can be string or object
    currency: string;
    manager: string;
    team: TeamMember[];
  } | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (project: any) => void;
  availablePrograms: string[];
  availableTeamMembers: any[];
}

const emptyProject = { id: '', code: '', title: '', program: '', currency: 'USD', manager: '', team: [] };

export function ProjectEditor({
  project,
  isOpen,
  onClose,
  onSave,
  availablePrograms = [],
  availableTeamMembers = [],
}: ProjectEditorProps) {
  
  const getInitialProgram = () => {
    if (!project) return '';
    if (typeof project.program === 'object' && project.program !== null) {
      return project.program.title;
    }
    return project.program;
  }

  const [currentProject, setCurrentProject] = useState({
      ...emptyProject,
      ...project,
      program: getInitialProgram(),
  });

  useEffect(() => {
     setCurrentProject({
      ...emptyProject,
      ...project,
      program: getInitialProgram(),
    });
  }, [project, isOpen]);

  const handleChange = (field: string, value: string) => {
    setCurrentProject(prev => ({ ...prev, [field]: value }));
  };
  
  const handleSelectChange = (field: string, value: string) => {
    handleChange(field, value);
  };

  const handleSave = () => {
    let updatedTeam = [...(currentProject.team || availableTeamMembers)];
    const newManagerName = currentProject.manager;
    const oldManagerName = project?.manager;
    
    // Only proceed if the manager has changed
    if (newManagerName && newManagerName !== oldManagerName) {
        
        // Find the new manager and set their role
        const newManagerIndex = updatedTeam.findIndex(m => m.name === newManagerName);
        if (newManagerIndex > -1) {
            updatedTeam[newManagerIndex] = { ...updatedTeam[newManagerIndex], role: 'PROJECT_MANAGER' };
        }

        // Find the old manager and demote them to Viewer
        if (oldManagerName) {
            const oldManagerIndex = updatedTeam.findIndex(m => m.name === oldManagerName);
            if (oldManagerIndex > -1) {
                 updatedTeam[oldManagerIndex] = { ...updatedTeam[oldManagerIndex], role: 'VIEWER' };
            }
        }
    }

    onSave({...currentProject, team: updatedTeam});
  };
  
  const title = project ? "Edit Project" : "Create New Project";
  const teamForDropdown = currentProject.team && currentProject.team.length > 0 ? currentProject.team : availableTeamMembers;


  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>
            {project ? "Make changes to your project here." : "Enter the details for the new project."}
             Click save when you're done.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="code" className="text-right">
              Code
            </Label>
            <Input
              id="code"
              value={currentProject.code}
              onChange={(e) => handleChange('code', e.target.value)}
              className="col-span-3"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="title" className="text-right">
              Title
            </Label>
            <Input
              id="title"
              value={currentProject.title}
              onChange={(e) => handleChange('title', e.target.value)}
              className="col-span-3"
            />
          </div>
           <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="program" className="text-right">
              Program
            </Label>
             <Select onValueChange={(value) => handleSelectChange('program', value)} value={currentProject.program}>
                <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Select a program" />
                </SelectTrigger>
                <SelectContent>
                    {availablePrograms.map((programName) => (
                        <SelectItem key={programName} value={programName}>
                            {programName}
                        </SelectItem>
                    ))}
                </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="manager" className="text-right">
              Project Manager
            </Label>
             <Select onValueChange={(value) => handleSelectChange('manager', value)} value={currentProject.manager}>
                <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Select a manager" />
                </SelectTrigger>
                <SelectContent>
                    {teamForDropdown.map((member) => (
                        <SelectItem key={member.id} value={member.name}>
                            {member.name}
                        </SelectItem>
                    ))}
                </SelectContent>
            </Select>
          </div>
           <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="currency" className="text-right">
              Currency
            </Label>
            <Input
              id="currency"
              value={currentProject.currency}
              onChange={(e) => handleChange('currency', e.target.value)}
              className="col-span-3"
              placeholder="e.g., USD, KES"
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSave}>Save Changes</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
