
'use client';

import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';

interface DisaggregatorSelectorProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (selected: string[]) => void;
  availableDisaggregators: string[];
  selectedDisaggregators: string[];
}

export function DisaggregatorSelector({
  isOpen,
  onClose,
  onSave,
  availableDisaggregators,
  selectedDisaggregators,
}: DisaggregatorSelectorProps) {
  const [selected, setSelected] = useState<string[]>(selectedDisaggregators);

  useEffect(() => {
    setSelected(selectedDisaggregators);
  }, [selectedDisaggregators]);

  const handleCheckboxChange = (disaggregator: string) => {
    setSelected(prev =>
      prev.includes(disaggregator)
        ? prev.filter(d => d !== disaggregator)
        : [...prev, disaggregator]
    );
  };

  const handleSave = () => {
    onSave(selected);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Select Disaggregators</DialogTitle>
          <DialogDescription>
            Choose the disaggregators for this project indicator.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4 max-h-60 overflow-y-auto">
          {availableDisaggregators.map(disaggregator => (
            <div key={disaggregator} className="flex items-center space-x-2">
              <Checkbox
                id={disaggregator}
                checked={selected.includes(disaggregator)}
                onCheckedChange={() => handleCheckboxChange(disaggregator)}
              />
              <Label htmlFor={disaggregator} className="font-normal">
                {disaggregator}
              </Label>
            </div>
          ))}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSave}>Save</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
