
'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableRow } from '@/components/ui/table';
import { PlusCircle, Edit, Trash2, ChevronDown, ChevronRight, Target } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { StrategicObjectiveEditor } from './strategic-objective-editor';
import { OutcomeEditor } from './outcome-editor';
import { OutputEditor } from './output-editor';
import { ActivityEditor } from './activity-editor';
import { IndicatorEditor } from './indicator-editor';

export function StrategicResultsFramework({ plan, setPlan }: { plan: any, setPlan: Function }) {
    const [openObjectives, setOpenObjectives] = useState<string[]>(plan.strategicObjectives.map((o: any) => o.id));
    const [openOutcomes, setOpenOutcomes] = useState<string[]>(plan.strategicObjectives.flatMap((o: any) => o.outcomes.map((out: any) => out.id)));

    // Editing State
    const [editingObjective, setEditingObjective] = useState<any>(null);
    const [editingOutcome, setEditingOutcome] = useState<any>(null);
    const [editingOutput, setEditingOutput] = useState<any>(null);
    const [editingActivity, setEditingActivity] = useState<any>(null);
    const [editingIndicator, setEditingIndicator] = useState<{value: string, parent: any} | null>(null);


    // Parent context for adding new items
    const [parentObjective, setParentObjective] = useState<any>(null);
    const [parentOutcome, setParentOutcome] = useState<any>(null);
    const [parentForIndicator, setParentForIndicator] = useState<any>(null);


    // Deleting State
    const [deletingItem, setDeletingItem] = useState<any>(null);

    const toggleObjective = (id: string) => {
        setOpenObjectives(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
    };
    
    const toggleOutcome = (id: string) => {
        setOpenOutcomes(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
    };

    // --- SAVE HANDLERS ---
    const handleSaveObjective = (objectiveToSave: any) => {
        if (objectiveToSave.id) { // Editing existing
            setPlan((prevPlan: any) => ({
                ...prevPlan,
                strategicObjectives: prevPlan.strategicObjectives.map((so: any) => so.id === objectiveToSave.id ? objectiveToSave : so)
            }));
        } else { // Adding new
            const newObjective = {
                ...objectiveToSave,
                id: `so-${Date.now()}`,
                number: `SO${plan.strategicObjectives.length + 1}`,
                corporateIndicators: [],
                outcomes: []
            };
            setPlan((prevPlan: any) => ({
                ...prevPlan,
                strategicObjectives: [...prevPlan.strategicObjectives, newObjective]
            }));
        }
        setEditingObjective(null);
    }
    
    const handleSaveOutcome = (outcomeToSave: any) => {
        if (outcomeToSave.id) { // Editing
             setPlan((prevPlan: any) => ({
                ...prevPlan,
                strategicObjectives: prevPlan.strategicObjectives.map((so: any) => ({
                    ...so,
                    outcomes: so.outcomes.map((o: any) => o.id === outcomeToSave.id ? outcomeToSave : o)
                }))
            }));
        } else { // Adding
            const newOutcome = { ...outcomeToSave, id: `outcome-${Date.now()}`, outputs: [], indicators: [] };
             setPlan((prevPlan: any) => ({
                ...prevPlan,
                strategicObjectives: prevPlan.strategicObjectives.map((so: any) => 
                    so.id === parentObjective.id 
                    ? { ...so, outcomes: [...so.outcomes, newOutcome] }
                    : so
                )
            }));
        }
        setEditingOutcome(null);
        setParentObjective(null);
    }

    const handleSaveOutput = (outputToSave: any) => {
        if (outputToSave.id) { // Editing
             setPlan((prevPlan: any) => ({
                ...prevPlan,
                strategicObjectives: prevPlan.strategicObjectives.map((so: any) => ({
                    ...so,
                    outcomes: so.outcomes.map((o: any) => ({
                        ...o,
                        outputs: o.outputs.map((op: any) => op.id === outputToSave.id ? outputToSave : op)
                    }))
                }))
            }));
        } else { // Adding
            const newOutput = { ...outputToSave, id: `output-${Date.now()}`, indicators: [], activities: [] };
            setPlan((prevPlan: any) => ({
                ...prevPlan,
                strategicObjectives: prevPlan.strategicObjectives.map((so: any) => ({
                    ...so,
                    outcomes: so.outcomes.map((o: any) => 
                        o.id === parentOutcome.id
                        ? { ...o, outputs: [...o.outputs, newOutput] }
                        : o
                    )
                }))
            }));
        }
        setEditingOutput(null);
        setParentOutcome(null);
    }

    const handleSaveActivity = (activityToSave: any) => {
        if (activityToSave.id) { // Editing
            // Logic to find and update the activity
        } else { // Adding
            const newActivity = { ...activityToSave, id: `activity-${Date.now()}` };
            // Logic to find parent output and add it
        }
        setEditingActivity(null);
    }

    const handleSaveIndicator = (indicatorValue: string) => {
        if (!parentForIndicator && !editingIndicator) return;
        
        const { parent, type, index } = editingIndicator ? editingIndicator.parent : parentForIndicator;
        const isEditing = editingIndicator !== null;

        const updateIndicators = (indicators: any[]) => {
            if (isEditing) {
                return indicators.map((ind, i) => i === index ? { ...ind, name: indicatorValue } : ind);
            }
            return [...indicators, { name: indicatorValue, disaggregators: [] }];
        };

        const updatedObjectives = plan.strategicObjectives.map((so: any) => ({
            ...so,
            outcomes: so.outcomes.map((o: any) => {
                if (type === 'outcome' && o.id === parent.id) {
                    return { ...o, indicators: updateIndicators(o.indicators) }
                }
                return {
                    ...o,
                    outputs: o.outputs.map((op: any) => {
                        if (type === 'output' && op.id === parent.id) {
                            return { ...op, indicators: updateIndicators(op.indicators) }
                        }
                        return op;
                    })
                };
            })
        }));

        setPlan({ ...plan, strategicObjectives: updatedObjectives });
        setEditingIndicator(null);
        setParentForIndicator(null);
    };

    
    // --- DELETE HANDLER ---
    const confirmDelete = () => {
        if (!deletingItem) return;
        
        const { type, id, parentId, grandParentId, greatGrandParentId, index } = deletingItem;
        
        let updatedObjectives = [...plan.strategicObjectives];

        if (type === 'objective') {
            updatedObjectives = updatedObjectives.filter(so => so.id !== id);
        } else if (type === 'outcome') {
            updatedObjectives = updatedObjectives.map(so => {
                if (so.id === parentId) {
                    return { ...so, outcomes: so.outcomes.filter((o: any) => o.id !== id) };
                }
                return so;
            });
        } else if (type === 'output') {
            updatedObjectives = updatedObjectives.map(so => {
                if (so.id === grandParentId) {
                    return {
                        ...so,
                        outcomes: so.outcomes.map((o: any) => {
                            if (o.id === parentId) {
                                return { ...o, outputs: o.outputs.filter((op: any) => op.id !== id) };
                            }
                            return o;
                        })
                    };
                }
                return so;
            });
        } else if (type === 'indicator') {
             updatedObjectives = updatedObjectives.map(so => {
                if (so.id === greatGrandParentId) {
                    return {
                        ...so,
                        outcomes: so.outcomes.map((o: any) => {
                            if (o.id === grandParentId) {
                                if(deletingItem.indicatorType === 'outcome'){
                                    const newIndicators = [...o.indicators];
                                    newIndicators.splice(index, 1);
                                    return {...o, indicators: newIndicators};
                                }
                                return {
                                    ...o,
                                    outputs: o.outputs.map((op: any) => {
                                        if (op.id === parentId) {
                                            const newIndicators = [...op.indicators];
                                            newIndicators.splice(index, 1);
                                            return { ...op, indicators: newIndicators };
                                        }
                                        return op;
                                    })
                                }
                            }
                            return o;
                        })
                    };
                }
                return so;
            });
        }
        
        setPlan({ ...plan, strategicObjectives: updatedObjectives });
        setDeletingItem(null);
    };

    const getIndicatorTitle = () => {
        if (!editingIndicator && !parentForIndicator) return "Add New Indicator";
        if (editingIndicator?.value) return "Edit Indicator";
        
        const { parent, type } = parentForIndicator || editingIndicator.parent;
        return `Add Indicator for ${type === 'outcome' ? 'Outcome' : 'Output'}: ${parent.name}`;
    }

    return (
        <>
            <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                        <CardTitle>Results Framework</CardTitle>
                        <CardDescription>
                            Define the hierarchy of objectives, outcomes, outputs, and activities for your strategic plan.
                        </CardDescription>
                    </div>
                     <Button onClick={() => setEditingObjective({})}>
                        <PlusCircle className="mr-2 h-4 w-4" />
                        Add Strategic Objective
                    </Button>
                </CardHeader>
                <CardContent>
                    <Table>
                        <TableBody>
                            {plan.strategicObjectives.map((objective: any) => (
                                <React.Fragment key={objective.id}>
                                    <TableRow className="bg-muted/50 hover:bg-muted/50">
                                        <TableCell colSpan={3} className="font-bold">
                                            <div className="flex items-center gap-2">
                                                <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => toggleObjective(objective.id)}>
                                                    {openObjectives.includes(objective.id) ? <ChevronDown className="h-5 w-5" /> : <ChevronRight className="h-5 w-5" />}
                                                </Button>
                                                <Target className="h-5 w-5 text-accent-foreground" />
                                                <Badge variant="secondary">{objective.number}</Badge>
                                                {objective.name}
                                            </div>
                                        </TableCell>
                                        <TableCell className="text-right">
                                            <Button variant="outline" size="sm" onClick={() => setEditingObjective(objective)}>
                                                <Edit className="mr-2 h-4 w-4" /> Edit
                                            </Button>
                                        </TableCell>
                                    </TableRow>

                                    {openObjectives.includes(objective.id) && (
                                        <>
                                            {objective.outcomes.map((outcome: any) => (
                                                <React.Fragment key={outcome.id}>
                                                    <TableRow>
                                                        <TableCell className="pl-16">
                                                             <div className="flex items-center gap-2">
                                                                <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => toggleOutcome(outcome.id)}>
                                                                    {openOutcomes.includes(outcome.id) ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                                                                </Button>
                                                                {outcome.name}
                                                            </div>
                                                        </TableCell>
                                                        <TableCell><Badge variant="outline">Outcome</Badge></TableCell>
                                                        <TableCell>{outcome.indicators?.length || 0} indicators</TableCell>
                                                        <TableCell className="text-right space-x-2">
                                                            <Button variant="outline" size="sm" onClick={() => setEditingOutcome(outcome)}>
                                                                <Edit className="mr-2 h-4 w-4" /> Edit
                                                            </Button>
                                                            <Button variant="destructive" size="sm" onClick={() => setDeletingItem({ type: 'outcome', name: outcome.name, id: outcome.id, parentId: objective.id })}>
                                                                <Trash2 className="mr-2 h-4 w-4" /> Delete
                                                            </Button>
                                                        </TableCell>
                                                    </TableRow>
                                                    {openOutcomes.includes(outcome.id) && (
                                                        <>
                                                            {(outcome.indicators || []).map((indicator: any, index: number) => (
                                                                <TableRow key={index}>
                                                                    <TableCell className="pl-28 text-sm text-muted-foreground">{indicator.name}</TableCell>
                                                                    <TableCell><Badge variant="ghost">Indicator</Badge></TableCell>
                                                                    <TableCell></TableCell>
                                                                    <TableCell className="text-right space-x-2">
                                                                        <Button variant="ghost" size="sm" onClick={() => setEditingIndicator({value: indicator.name, parent: {parent: outcome, type: 'outcome', index}})}>Edit</Button>
                                                                        <Button variant="ghost" size="sm" className="text-red-600" onClick={() => setDeletingItem({ type: 'indicator', indicatorType: 'outcome', name: indicator.name, index, parentId: null, grandParentId: outcome.id, greatGrandParentId: objective.id })}>Delete</Button>
                                                                    </TableCell>
                                                                </TableRow>
                                                            ))}
                                                            <TableRow>
                                                                <TableCell colSpan={4} className="pl-28 py-1">
                                                                    <Button variant="ghost" size="sm" className="w-full justify-start text-muted-foreground" onClick={() => { setParentForIndicator({ parent: outcome, type: 'outcome' }); setEditingIndicator({value: '', parent: null}); }}>
                                                                        <PlusCircle className="mr-2 h-4 w-4" /> Add Outcome Indicator
                                                                    </Button>
                                                                </TableCell>
                                                            </TableRow>
                                                            {outcome.outputs.map((output: any) => (
                                                                <React.Fragment key={output.id}>
                                                                <TableRow>
                                                                    <TableCell className="pl-28">{output.name}</TableCell>
                                                                    <TableCell><Badge variant="outline">Output</Badge></TableCell>
                                                                    <TableCell>{output.indicators?.length || 0} indicators</TableCell>
                                                                    <TableCell className="text-right space-x-2">
                                                                        <Button variant="ghost" size="sm" onClick={() => { setParentOutcome(outcome); setEditingOutput(output); }}>Edit</Button>
                                                                        <Button variant="ghost" size="sm" className="text-red-600" onClick={() => setDeletingItem({ type: 'output', name: output.name, id: output.id, parentId: outcome.id, grandParentId: objective.id })}>Delete</Button>
                                                                    </TableCell>
                                                                </TableRow>
                                                                    {(output.indicators || []).map((indicator: any, index: number) => (
                                                                    <TableRow key={index}>
                                                                        <TableCell className="pl-36 text-sm text-muted-foreground">{indicator.name}</TableCell>
                                                                        <TableCell><Badge variant="ghost">Indicator</Badge></TableCell>
                                                                        <TableCell></TableCell>
                                                                        <TableCell className="text-right space-x-2">
                                                                            <Button variant="ghost" size="sm" onClick={() => setEditingIndicator({value: indicator.name, parent: {parent: output, type: 'output', index}})}>Edit</Button>
                                                                            <Button variant="ghost" size="sm" className="text-red-600" onClick={() => setDeletingItem({ type: 'indicator', indicatorType: 'output', name: indicator.name, index, parentId: output.id, grandParentId: outcome.id, greatGrandParentId: objective.id })}>Delete</Button>
                                                                        </TableCell>
                                                                    </TableRow>
                                                                    ))}
                                                                    <TableRow>
                                                                        <TableCell colSpan={4} className="pl-36 py-1">
                                                                            <Button variant="ghost" size="sm" className="w-full justify-start text-muted-foreground" onClick={() => { setParentForIndicator({ parent: output, type: 'output' }); setEditingIndicator({value: '', parent: null}); }}>
                                                                                <PlusCircle className="mr-2 h-4 w-4" /> Add Output Indicator
                                                                            </Button>
                                                                        </TableCell>
                                                                    </TableRow>
                                                                </React.Fragment>
                                                            ))}
                                                            <TableRow>
                                                                <TableCell colSpan={4} className="pl-28">
                                                                    <Button variant="secondary" size="sm" onClick={() => { setParentOutcome(outcome); setEditingOutput({}); }}>
                                                                        <PlusCircle className="mr-2 h-4 w-4" /> Add Output
                                                                    </Button>
                                                                </TableCell>
                                                            </TableRow>
                                                        </>
                                                    )}
                                                </React.Fragment>
                                            ))}
                                            <TableRow>
                                                <TableCell colSpan={4} className="pl-16">
                                                    <Button variant="outline" size="sm" onClick={() => { setParentObjective(objective); setEditingOutcome({}); }}>
                                                        <PlusCircle className="mr-2 h-4 w-4" /> Add Outcome
                                                    </Button>
                                                </TableCell>
                                            </TableRow>
                                        </>
                                    )}
                                </React.Fragment>
                            ))}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>
            
            {/* Editor Modals */}
            {editingObjective !== null && (
                <StrategicObjectiveEditor
                    objective={editingObjective}
                    isOpen={editingObjective !== null}
                    onClose={() => setEditingObjective(null)}
                    onSave={handleSaveObjective}
                />
            )}
            {editingOutcome && (
                <OutcomeEditor
                    outcome={editingOutcome}
                    isOpen={!!editingOutcome}
                    onClose={() => setEditingOutcome(null)}
                    onSave={handleSaveOutcome}
                />
            )}
            {editingOutput && (
                <OutputEditor
                    output={editingOutput}
                    isOpen={!!editingOutput}
                    onClose={() => setEditingOutput(null)}
                    onSave={handleSaveOutput}
                />
            )}
            {editingIndicator !== null && (
                <IndicatorEditor
                    indicator={editingIndicator.value}
                    isOpen={editingIndicator !== null}
                    onClose={() => {setEditingIndicator(null); setParentForIndicator(null);}}
                    onSave={handleSaveIndicator}
                    title={getIndicatorTitle()}
                />
            )}
            
            {/* Delete Confirmation */}
            {deletingItem && (
                <AlertDialog open={!!deletingItem} onOpenChange={() => setDeletingItem(null)}>
                    <AlertDialogContent>
                        <AlertDialogHeader>
                            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                            <AlertDialogDescription>
                                This action cannot be undone. This will permanently delete the {deletingItem.type} "{deletingItem.name}" and all of its children.
                            </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={confirmDelete} className="bg-destructive hover:bg-destructive/90">Delete</AlertDialogAction>
                        </AlertDialogFooter>
                    </AlertDialogContent>
                </AlertDialog>
            )}
        </>
    );
}
