import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface IndicatorEditorProps {
  indicator: string;
  isOpen: boolean;
  onClose: () => void;
  onSave: (value: string) => void;
  title?: string;
}

export function IndicatorEditor({
  indicator,
  isOpen,
  onClose,
  onSave,
  title = "Edit Indicator",
}: IndicatorEditorProps) {
  const [currentValue, setCurrentValue] = useState(indicator);

  useEffect(() => {
    setCurrentValue(indicator);
  }, [indicator]);

  const handleSave = () => {
    if (currentValue.trim()) {
      onSave(currentValue);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>
            Enter the new value for the indicator.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="indicator-value" className="text-right">
              Indicator
            </Label>
            <Input
              id="indicator-value"
              value={currentValue}
              onChange={(e) => setCurrentValue(e.target.value)}
              className="col-span-3"
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSave}>Save</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
