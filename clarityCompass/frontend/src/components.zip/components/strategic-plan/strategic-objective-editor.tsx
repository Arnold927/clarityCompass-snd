import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

interface StrategicObjectiveEditorProps {
  objective: any;
  isOpen: boolean;
  onClose: () => void;
  onSave: (objective: any) => void;
}

const emptyObjective = {
    name: '',
    description: ''
};

export function StrategicObjectiveEditor({
  objective,
  isOpen,
  onClose,
  onSave,
}: StrategicObjectiveEditorProps) {
  const [currentObjective, setCurrentObjective] = useState(objective?.id ? objective : emptyObjective);
  
  const isEditing = !!objective?.id;

  useEffect(() => {
    setCurrentObjective(objective?.id ? objective : emptyObjective);
  }, [objective, isOpen]);

  const handleChange = (field: string, value: string) => {
    setCurrentObjective(prev => ({ ...prev, [field]: value }));
  };

  const handleSave = () => {
    onSave(currentObjective);
  };
  
  const title = isEditing ? `Edit Strategic Objective (${objective.number})` : "Add New Strategic Objective";

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>
            Make changes to your strategic objective here. Click save when you're done.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="name" className="text-right">
              Name
            </Label>
            <Input
              id="name"
              value={currentObjective.name}
              onChange={(e) => handleChange('name', e.target.value)}
              className="col-span-3"
            />
          </div>
          <div className="grid grid-cols-4 items-start gap-4">
            <Label htmlFor="description" className="text-right pt-2">
              Description
            </Label>
            <Textarea
              id="description"
              value={currentObjective.description}
              onChange={(e) => handleChange('description', e.target.value)}
              className="col-span-3"
              rows={5}
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSave}>Save Changes</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
