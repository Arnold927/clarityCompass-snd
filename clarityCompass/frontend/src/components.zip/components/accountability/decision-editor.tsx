
'use client';

import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";

interface DecisionEditorProps {
  decision: any | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (decision: any) => void;
  availableStatuses: string[];
  availableOwners: string[];
}

const emptyDecision = { id: null, decision: '', owner: '', deadline: '', status: '' };

export function DecisionEditor({
  decision,
  isOpen,
  onClose,
  onSave,
  availableStatuses,
  availableOwners,
}: DecisionEditorProps) {
  const [currentDecision, setCurrentDecision] = useState(decision || emptyDecision);

  useEffect(() => {
    setCurrentDecision(decision || emptyDecision);
  }, [decision, isOpen]);

  const handleChange = (field: string, value: string) => {
    setCurrentDecision(prev => ({ ...prev, [field]: value }));
  };

  const handleSave = () => {
    onSave(currentDecision);
  };
  
  const title = decision ? "Edit Decision" : "Create New Decision";

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>
            {decision ? "Make changes to the decision." : "Enter the details for the new decision."}
             Click save when you're done.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="decision">Decision</Label>
            <Textarea
              id="decision"
              value={currentDecision.decision}
              onChange={(e) => handleChange('decision', e.target.value)}
              className="col-span-3"
              rows={3}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="owner">Owner</Label>
            <Select onValueChange={(value) => handleChange('owner', value)} value={currentDecision.owner}>
                <SelectTrigger id="owner">
                    <SelectValue placeholder="Select an owner" />
                </SelectTrigger>
                <SelectContent>
                    {availableOwners.map((ownerName) => (
                        <SelectItem key={ownerName} value={ownerName}>
                            {ownerName}
                        </SelectItem>
                    ))}
                </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="deadline">Deadline</Label>
            <Input
              id="deadline"
              type="date"
              value={currentDecision.deadline}
              onChange={(e) => handleChange('deadline', e.target.value)}
              className="col-span-3"
            />
          </div>
           <div className="space-y-2">
            <Label htmlFor="status">Status</Label>
             <Select onValueChange={(value) => handleChange('status', value)} value={currentDecision.status}>
                <SelectTrigger id="status">
                    <SelectValue placeholder="Select a status" />
                </SelectTrigger>
                <SelectContent>
                    {availableStatuses.map((statusName) => (
                        <SelectItem key={statusName} value={statusName}>
                            {statusName}
                        </SelectItem>
                    ))}
                </SelectContent>
            </Select>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSave}>Save Changes</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
