

'use client';

import React, { useState, useEffect, useRef } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
  DialogClose
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon, FileBarChart, Trash2, Upload, Check, ChevronsUpDown } from "lucide-react";
import { Calendar } from "../ui/calendar";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { Checkbox } from "../ui/checkbox";
import { TaskIndicatorDataEntry } from "./task-indicator-data-entry";
import { Badge } from "../ui/badge";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "../ui/command";

interface TaskEditorProps {
  task: any | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (task: any) => void;
  projectActivities: any[];
  projectTeam: any[];
  projectIndicators: any[];
  projectLocations: any[];
  projectCurrency: string;
}

const emptyTask = {
  title: '',
  description: '',
  activityId: '',
  focalPersonId: '',
  locationIds: [],
  startDate: '',
  endDate: '',
  budget: '',
  updates: [],
  indicatorData: {},
  attachments: [],
};

const emptyUpdate = {
    statusDate: null,
    status: 'green',
    statusJustification: '',
    isComplete: false,
    amountSpent: '',
}

export function TaskEditor({
  task,
  isOpen,
  onClose,
  onSave,
  projectActivities,
  projectTeam,
  projectIndicators,
  projectLocations,
  projectCurrency,
}: TaskEditorProps) {
  const [currentTask, setCurrentTask] = useState(task || emptyTask);
  const [currentUpdate, setCurrentUpdate] = useState(emptyUpdate);

  const [startDate, setStartDate] = useState<Date | undefined>();
  const [endDate, setEndDate] = useState<Date | undefined>();
  
  const [isIndicatorEntryOpen, setIsIndicatorEntryOpen] = useState(false);
  const [isLocationPopoverOpen, setIsLocationPopoverOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const isEditing = !!task;
  const isFutureTask = isEditing && startDate ? new Date(startDate) > new Date() : false;
  const canSaveNew = currentTask.title.trim() !== '' && currentTask.description.trim() !== '' && currentTask.activityId && currentTask.focalPersonId && currentTask.locationIds.length > 0 && startDate && endDate && currentTask.budget;
  
  const linkedActivity = projectActivities.find(a => a.id === currentTask.activityId);
  const linkedIndicator = linkedActivity ? projectIndicators.find(i => i.id === linkedActivity.linkedIndicatorId) : null;
  const selectedLocations = projectLocations.filter(l => currentTask.locationIds?.includes(l.id));


  useEffect(() => {
    if (isOpen) {
      const initialTask = task ? { ...task, locationIds: task.locationIds || [] } : { ...emptyTask, updates: [], indicatorData: {}, attachments: [], locationIds: [] };
      setCurrentTask(initialTask);
      setCurrentUpdate(emptyUpdate);
      setStartDate(initialTask.startDate ? new Date(initialTask.startDate) : undefined);
      setEndDate(initialTask.endDate ? new Date(initialTask.endDate) : undefined);
    }
  }, [task, isOpen]);
  
  const handleTaskChange = (field: string, value: string | boolean | any[]) => {
    setCurrentTask(prev => ({ ...prev, [field]: value }));
  };

  const handleLocationSelect = (locationId: string) => {
    const currentIds = currentTask.locationIds || [];
    const newIds = currentIds.includes(locationId)
      ? currentIds.filter((id: string) => id !== locationId)
      : [...currentIds, locationId];
    handleTaskChange('locationIds', newIds);
  };


  const handleUpdateChange = (field: string, value: string | boolean) => {
    setCurrentUpdate(prev => ({ ...prev, [field]: value }));
  };
  
  const handleAttachmentUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
      if (event.target.files) {
          const files = Array.from(event.target.files);
          const newAttachments = files.map(file => ({ name: file.name, size: file.size }));
          handleTaskChange('attachments', [...(currentTask.attachments || []), ...newAttachments]);
      }
  };

  const handleRemoveAttachment = (attachmentName: string) => {
      handleTaskChange('attachments', currentTask.attachments.filter((att: any) => att.name !== attachmentName));
  };


  const handleSave = () => {
    if (isEditing) {
        const newUpdate = {
            ...currentUpdate,
            statusDate: format(new Date(), 'yyyy-MM-dd'),
        };
        const updatedTask = {
            ...currentTask,
            updates: [...(currentTask.updates || []), newUpdate],
        };
        onSave(updatedTask);
    } else {
        if (!canSaveNew) return;
        const finalTask = {
            ...currentTask,
            startDate: startDate ? format(startDate, 'yyyy-MM-dd') : '',
            endDate: endDate ? format(endDate, 'yyyy-MM-dd') : '',
            activityName: projectActivities.find(a => a.id === currentTask.activityId)?.name,
            focalPersonName: projectTeam.find(p => p.id === currentTask.focalPersonId)?.name,
        };
        onSave(finalTask);
    }
  };
  
  const handleIndicatorDataSave = (data: any) => {
      handleTaskChange('indicatorData', data);
      setIsIndicatorEntryOpen(false);
  }

  const title = task ? "Update Task Status" : "Create New Task";

  return (
    <>
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{title}</DialogTitle>
             <DialogDescription>
              {isEditing ? `Updating task: ${task.title}` : "Enter the details for the new task."}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-6 py-4 pr-2">
            <fieldset disabled={isEditing}>
                <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="title" className="text-right">Title</Label>
                    <Input id="title" value={currentTask.title} onChange={(e) => handleTaskChange('title', e.target.value)} className="col-span-3" />
                </div>
                <div className="grid grid-cols-4 items-start gap-4 mt-4">
                    <Label htmlFor="description" className="text-right pt-2">Description</Label>
                    <Textarea id="description" value={currentTask.description} onChange={(e) => handleTaskChange('description', e.target.value)} className="col-span-3" rows={3} />
                </div>
                <div className="grid grid-cols-4 items-center gap-4 mt-4">
                    <Label htmlFor="activityId" className="text-right">Key Activity</Label>
                    <Select onValueChange={(val) => handleTaskChange('activityId', val)} value={currentTask.activityId}>
                        <SelectTrigger className="col-span-3"><SelectValue placeholder="Link to an activity" /></SelectTrigger>
                        <SelectContent>{projectActivities.map(act => <SelectItem key={act.id} value={act.id}>{act.name}</SelectItem>)}</SelectContent>
                    </Select>
                </div>
                 <div className="grid grid-cols-4 items-center gap-4 mt-4">
                    <Label htmlFor="locationId" className="text-right">Location(s)</Label>
                    <Popover open={isLocationPopoverOpen} onOpenChange={setIsLocationPopoverOpen}>
                        <PopoverTrigger asChild>
                            <Button variant="outline" role="combobox" aria-expanded={isLocationPopoverOpen} className="col-span-3 justify-between h-auto">
                                <div className="flex gap-1 flex-wrap">
                                    {selectedLocations.length > 0 ? selectedLocations.map(l => <Badge key={l.id} variant="secondary">{l.name}</Badge>) : "Select location(s)..."}
                                </div>
                                <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                            </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-[--radix-popover-trigger-width] p-0">
                            <Command>
                                <CommandInput placeholder="Search locations..." />
                                <CommandList>
                                    <CommandEmpty>No locations found.</CommandEmpty>
                                    <CommandGroup>
                                        {projectLocations.map((location) => (
                                        <CommandItem
                                            key={location.id}
                                            value={location.name}
                                            onSelect={() => handleLocationSelect(location.id)}
                                        >
                                            <Check className={cn("mr-2 h-4 w-4", currentTask.locationIds?.includes(location.id) ? "opacity-100" : "opacity-0")}/>
                                            {location.name}
                                        </CommandItem>
                                        ))}
                                    </CommandGroup>
                                </CommandList>
                            </Command>
                        </PopoverContent>
                    </Popover>
                </div>
                <div className="grid grid-cols-4 items-center gap-4 mt-4">
                    <Label htmlFor="focalPersonId" className="text-right">Focal Person</Label>
                    <Select onValueChange={(val) => handleTaskChange('focalPersonId', val)} value={currentTask.focalPersonId}>
                        <SelectTrigger className="col-span-3"><SelectValue placeholder="Assign a team member" /></SelectTrigger>
                        <SelectContent>{projectTeam.map(mem => <SelectItem key={mem.id} value={mem.id}>{mem.name} ({mem.role.replace(/_/g, ' ')})</SelectItem>)}</SelectContent>
                    </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4 mt-4">
                    <Label className="text-right">Start - End Dates</Label>
                    <div className="col-span-3 grid grid-cols-2 gap-2">
                          <Popover>
                            <PopoverTrigger asChild>
                                <Button variant={"outline"} className={cn("justify-start text-left font-normal", !startDate && "text-muted-foreground")}>
                                    <CalendarIcon className="mr-2 h-4 w-4" />{startDate ? format(startDate, "PPP") : <span>Pick a start date</span>}
                                </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0"><Calendar mode="single" selected={startDate} onSelect={setStartDate} initialFocus /></PopoverContent>
                        </Popover>
                          <Popover>
                            <PopoverTrigger asChild>
                                <Button variant={"outline"} className={cn("justify-start text-left font-normal", !endDate && "text-muted-foreground")}>
                                    <CalendarIcon className="mr-2 h-4 w-4" />{endDate ? format(endDate, "PPP") : <span>Pick an end date</span>}
                                </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0"><Calendar mode="single" selected={endDate} onSelect={setEndDate} initialFocus /></PopoverContent>
                        </Popover>
                    </div>
                </div>
                <div className="grid grid-cols-4 items-center gap-4 mt-4">
                    <Label htmlFor="budget" className="text-right">Budget ({projectCurrency})</Label>
                    <Input id="budget" type="number" value={currentTask.budget} onChange={(e) => handleTaskChange('budget', e.target.value)} className="col-span-3" />
                </div>
            </fieldset>

            {/* Task Update Fields - Only show when editing */}
            {isEditing && (
              <fieldset disabled={isFutureTask} className="mt-6 border-t pt-6">
                  <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="statusDate" className="text-right">Status Date</Label>
                        <Button variant={"outline"} disabled className={cn("col-span-3 justify-start text-left font-normal")}>
                            <CalendarIcon className="mr-2 h-4 w-4" />{format(new Date(), "PPP")}
                        </Button>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4 mt-4">
                    <Label htmlFor="status" className="text-right">Status</Label>
                    <Select onValueChange={(val) => handleUpdateChange('status', val)} value={currentUpdate.status}>
                        <SelectTrigger className="col-span-3"><SelectValue placeholder="Set task status" /></SelectTrigger>
                        <SelectContent>
                            <SelectItem value="green">Green (On Track)</SelectItem>
                            <SelectItem value="amber">Amber (At Risk)</SelectItem>
                            <SelectItem value="red">Red (Off Track)</SelectItem>
                        </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-start gap-4 mt-4">
                    <Label htmlFor="statusJustification" className="text-right pt-2">Justification</Label>
                    <Textarea id="statusJustification" value={currentUpdate.statusJustification} onChange={(e) => handleUpdateChange('statusJustification', e.target.value)} className="col-span-3" rows={2} placeholder="Briefly explain the status..." />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4 mt-4">
                    <Label htmlFor="amountSpent" className="text-right">Amount Spent ({projectCurrency})</Label>
                    <Input id="amountSpent" type="number" value={currentUpdate.amountSpent} onChange={(e) => handleUpdateChange('amountSpent', e.target.value)} className="col-span-3" />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4 mt-4">
                      <Label className="text-right">Mark as Complete</Label>
                      <div className="col-span-3 flex items-center space-x-2">
                        <Checkbox id="isComplete" checked={currentUpdate.isComplete} onCheckedChange={(checked) => handleUpdateChange('isComplete', checked as boolean)} />
                        <Label htmlFor="isComplete" className="font-normal">The task is fully completed.</Label>
                    </div>
                  </div>
                  <div className="grid grid-cols-4 items-start gap-4 mt-4">
                      <Label className="text-right pt-2">Reporting</Label>
                      <div className="col-span-3 space-y-2">
                          <input type="file" ref={fileInputRef} onChange={handleAttachmentUpload} className="hidden" multiple />
                          <Button variant="outline" onClick={() => setIsIndicatorEntryOpen(true)} disabled={!linkedIndicator}>
                              <FileBarChart className="mr-2 h-4 w-4" />Report Indicator Data
                          </Button>
                          <Button variant="outline" onClick={() => fileInputRef.current?.click()}><Upload className="mr-2 h-4 w-4" />Upload Documents</Button>
                          {!linkedIndicator && <p className="text-xs text-muted-foreground">This task's key activity is not linked to a project indicator.</p>}
                          
                          {(currentTask.attachments || []).length > 0 && (
                            <div className="space-y-2 pt-2">
                                <p className="text-sm font-medium">Attachments:</p>
                                <ul className="space-y-1">
                                    {currentTask.attachments.map((att: any, index: number) => (
                                        <li key={index} className="flex items-center justify-between text-sm p-2 bg-muted rounded-md">
                                            <span>{att.name}</span>
                                            <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => handleRemoveAttachment(att.name)}>
                                                <Trash2 className="h-4 w-4 text-red-500" />
                                            </Button>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                          )}

                      </div>
                  </div>

                  {isFutureTask && (
                  <div className="text-center text-sm text-muted-foreground p-4 bg-muted rounded-md col-span-full mt-4">
                      Reporting and status updates for this task can be filled in once the start date ({startDate ? format(startDate, "PPP") : ''}) is reached.
                  </div>
                  )}
              </fieldset>
            )}

          </div>
          <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline">Cancel</Button>
            </DialogClose>
            <Button onClick={handleSave} disabled={!isEditing && !canSaveNew}>Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      {isIndicatorEntryOpen && linkedIndicator && (
          <TaskIndicatorDataEntry 
              isOpen={isIndicatorEntryOpen}
              onClose={() => setIsIndicatorEntryOpen(false)}
              onSave={handleIndicatorDataSave}
              indicator={linkedIndicator}
              initialData={currentTask.indicatorData}
          />
      )}
    </>
  );
}
