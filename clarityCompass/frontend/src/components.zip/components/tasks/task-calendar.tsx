

'use client';

import React, { useState } from 'react';
import { Calendar } from '@/components/ui/calendar';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { PlusCircle } from 'lucide-react';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { TaskDetailsPopover } from './task-details-popover';
import { addDays, format, isSameDay, isSameMonth, isWithinInterval, startOfDay } from 'date-fns';
import { cn } from '@/lib/utils';

export function TaskCalendar({ tasks, locations, onAddTask, onEditTask, projectCurrency }: { tasks: any[], locations: any[], onAddTask: () => void, onEditTask: (task: any) => void, projectCurrency: string }) {
  const [date, setDate] = useState<Date | undefined>(new Date());
  
  const tasksForSelectedMonth = tasks.filter(task => isSameMonth(new Date(task.startDate), date || new Date()));
  const getLatestUpdate = (task: any) => task.updates?.[task.updates.length - 1];

  const getTaskColor = (task: any) => {
    const latestUpdate = getLatestUpdate(task);
    if (!latestUpdate) return 'bg-gray-400/20 text-gray-600 border-gray-400/30';

    switch (latestUpdate.status) {
      case 'red': return 'bg-red-500/20 text-red-700 border-red-500/30';
      case 'amber': return 'bg-yellow-500/20 text-yellow-700 border-yellow-500/30';
      case 'green': return 'bg-green-500/20 text-green-700 border-green-500/30';
      default: return 'bg-gray-400/20 text-gray-600 border-gray-400/30';
    }
  };
  
  const getTaskDotColor = (task: any) => {
      const latestUpdate = getLatestUpdate(task);
      if (!latestUpdate) return 'bg-gray-400';

      switch (latestUpdate.status) {
        case 'red': return 'bg-red-500';
        case 'amber': return 'bg-yellow-500';
        case 'green': return 'bg-green-500';
        default: return 'bg-gray-400';
      }
  };

  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between">
        <div>
          <CardTitle>Task Manager</CardTitle>
          <CardDescription>Manage project tasks, assignees, and deadlines.</CardDescription>
        </div>
        <Button onClick={onAddTask}>
          <PlusCircle className="mr-2 h-4 w-4" />
          Create Task
        </Button>
      </CardHeader>
      <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
            <Calendar
                mode="single"
                selected={date}
                onSelect={setDate}
                className="rounded-md border"
                modifiers={{
                    ...tasks.reduce((acc, task) => {
                        if (task.startDate && task.endDate) {
                            acc[task.id] = { from: new Date(task.startDate), to: new Date(task.endDate) };
                        }
                        return acc;
                    }, {})
                }}
                modifiersClassNames={{
                    ...tasks.reduce((acc, task) => {
                        acc[task.id] = getTaskColor(task);
                        return acc;
                    }, {})
                }}
                components={{
                    DayContent: ({ date, ...props }) => {
                        const dailyTasks = tasks.filter(task => isSameDay(new Date(task.startDate), date));
                        return (
                            <div className="relative h-full w-full flex flex-col items-center justify-center">
                                <span {...props.buttonProps}>{format(date, 'd')}</span>
                                {dailyTasks.length > 0 && (
                                    <div className="flex -space-x-1 mt-1">
                                        {dailyTasks.map(task => (
                                            <Popover key={task.id}>
                                                <PopoverTrigger asChild>
                                                    <span className={cn("h-2 w-2 rounded-full cursor-pointer", getTaskDotColor(task))} />
                                                </PopoverTrigger>
                                                <PopoverContent className="w-80">
                                                    <TaskDetailsPopover task={task} locations={locations} onEditTask={onEditTask} projectCurrency={projectCurrency} />
                                                </PopoverContent>
                                            </Popover>
                                        ))}
                                    </div>
                                )}
                            </div>
                        );
                    }
                }}
            />
        </div>
        <div className="space-y-4">
            <h3 className="text-lg font-semibold">Tasks for {format(date || new Date(), 'MMMM yyyy')}</h3>
            <div className="space-y-2 max-h-96 overflow-y-auto pr-2">
                {tasksForSelectedMonth.length > 0 ? (
                    tasksForSelectedMonth.map(task => (
                         <Popover key={task.id}>
                            <PopoverTrigger asChild>
                                <div key={task.id} className="p-3 rounded-md border flex items-center gap-3 cursor-pointer hover:bg-muted/50">
                                    <span className={cn("h-3 w-3 rounded-full shrink-0", getTaskDotColor(task))}></span>
                                    <div>
                                        <p className="font-medium text-sm">{task.title}</p>
                                        <p className="text-xs text-muted-foreground">{format(new Date(task.startDate), 'MMM d')} - {format(new Date(task.endDate), 'MMM d')}</p>
                                    </div>
                                </div>
                            </PopoverTrigger>
                             <PopoverContent className="w-80">
                                <TaskDetailsPopover task={task} locations={locations} onEditTask={onEditTask} projectCurrency={projectCurrency} />
                            </PopoverContent>
                        </Popover>
                    ))
                ) : (
                    <p className="text-sm text-muted-foreground">No tasks scheduled for this month.</p>
                )}
            </div>
        </div>
      </CardContent>
    </Card>
  );
}
