

'use client';

import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Edit, MapPin, PencilRuler } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { format } from 'date-fns';

export function TaskDetailsPopover({ task, locations, onEditTask, projectCurrency }: { task: any, locations: any[], onEditTask: (task: any) => void, projectCurrency: string }) {
  
  const latestUpdate = task.updates?.[task.updates.length - 1];
  const totalSpent = task.updates?.reduce((sum: number, u: any) => sum + (Number(u.amountSpent) || 0), 0) || 0;
  const taskLocations = locations?.filter(l => task.locationIds?.includes(l.id)).map(l => l.name) || [];


  const getStatusColor = () => {
    if (!latestUpdate) return 'bg-gray-400';
    switch (latestUpdate.status) {
      case 'red': return 'bg-red-500';
      case 'amber': return 'bg-yellow-500';
      case 'green': return 'bg-green-500';
      default: return 'bg-gray-400';
    }
  };

  return (
    <div className="space-y-3">
        <div className="flex justify-between items-start">
            <div>
                <h4 className="font-bold">{task.title}</h4>
                <p className="text-sm text-muted-foreground">{task.activityName}</p>
            </div>
             <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => onEditTask(task)}>
                <Edit className="h-4 w-4" />
            </Button>
        </div>
        <Separator />
        <p className="text-sm">{task.description || "No description provided."}</p>
        
        {taskLocations.length > 0 && <div className="flex items-start">
            <MapPin className="mr-1.5 h-4 w-4 text-muted-foreground mt-0.5 shrink-0" />
            <div className="flex flex-wrap gap-1">
              {taskLocations.map(loc => <Badge key={loc} variant="secondary" className="font-normal">{loc}</Badge>)}
            </div>
        </div>}

        <div className="text-sm space-y-1">
            <p><strong>Focal Person:</strong> {task.focalPersonName}</p>
            <p><strong>Dates:</strong> {format(new Date(task.startDate), 'MMM d, yyyy')} - {format(new Date(task.endDate), 'MMM d, yyyy')}</p>
            <p><strong>Budget:</strong> {projectCurrency} {task.budget?.toLocaleString()}</p>
            <p><strong>Amount Spent:</strong> {projectCurrency} {totalSpent.toLocaleString()}</p>
        </div>
         {latestUpdate && (
             <div className="text-sm space-y-1">
                <p><strong>Last Update:</strong> {format(new Date(latestUpdate.statusDate), 'MMM d, yyyy')}</p>
                <div className="flex items-center gap-2">
                    <Badge className={`capitalize text-white ${getStatusColor()}`}>{latestUpdate.status}</Badge>
                    <p className="text-xs text-muted-foreground italic">{latestUpdate.statusJustification}</p>
                </div>
            </div>
         )}
        {latestUpdate?.isComplete && <Badge variant="secondary">Completed</Badge>}
        
        <Separator />

        <Button className="w-full" size="sm" onClick={() => onEditTask(task)}>
            <PencilRuler className="mr-2 h-4 w-4" />
            Update Status
        </Button>
    </div>
  );
}
