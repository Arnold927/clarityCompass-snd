

'use client';

import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "../ui/checkbox";
import { Separator } from "../ui/separator";
import { GripVertical, PlusCircle, Trash2 } from "lucide-react";
import { subFieldTypes } from "@/lib/mock-data";

interface FieldEditorProps {
  field: any;
  formFields: any[]; // All fields in the form
  isOpen: boolean;
  onClose: () => void;
  onSave: (field: any) => void;
  availableTypes: string[];
}

export function FieldEditor({
  field,
  formFields,
  isOpen,
  onClose,
  onSave,
  availableTypes
}: FieldEditorProps) {
  const [currentField, setCurrentField] = useState(field);
  const [hasCondition, setHasCondition] = useState(false);

  useEffect(() => {
    const initialField = {
      ...field,
      fields: field.fields || [],
      options: field.options || [],
    }
    setCurrentField(initialField);
    setHasCondition(!!field.condition);
  }, [field, isOpen]);

  const handleChange = (prop: string, value: any) => {
    setCurrentField((prev: any) => ({ ...prev, [prop]: value }));
  };
  
  const handleTypeChange = (value: any) => {
    const newField = { ...currentField, type: value };
    if (value === 'field_group') {
      newField.fields = newField.fields || [];
    }
     if (value === 'select' || value === 'checkbox') {
      newField.options = newField.options || [];
    }
    setCurrentField(newField);
  }

  const handleOptionChange = (index: number, value: string) => {
    const newOptions = [...currentField.options];
    newOptions[index] = value;
    handleChange('options', newOptions);
  };
  
  const handleAddOption = () => {
    const newOptions = [...currentField.options, 'New Option'];
    handleChange('options', newOptions);
  };
  
  const handleRemoveOption = (index: number) => {
     const newOptions = [...currentField.options];
     newOptions.splice(index, 1);
     handleChange('options', newOptions);
  }

  // Sub-field handlers
  const handleAddSubField = () => {
    const newSubField = {
        id: `${currentField.id}-${currentField.fields.length + 1}`,
        label: 'New Sub-Field',
        type: 'text',
        required: false,
    };
    handleChange('fields', [...currentField.fields, newSubField]);
  }

  const handleSubFieldChange = (index: number, prop: string, value: any) => {
    const newSubFields = [...currentField.fields];
    newSubFields[index] = { ...newSubFields[index], [prop]: value };
    handleChange('fields', newSubFields);
  }
  
  const handleRemoveSubField = (index: number) => {
    const newSubFields = [...currentField.fields];
    newSubFields.splice(index, 1);
    handleChange('fields', newSubFields);
  }

  const handleConditionToggle = (checked: boolean) => {
    setHasCondition(checked);
    if (!checked) {
        // Remove condition from field if it exists
        const { condition, ...rest } = currentField;
        setCurrentField(rest);
    } else {
        // Add a default empty condition
        handleChange('condition', { fieldId: '', operator: 'equals', value: '' });
    }
  }
  
  const handleConditionChange = (prop: string, value: string) => {
    handleChange('condition', { ...currentField.condition, [prop]: value });
  }


  const handleSave = () => {
    onSave(currentField);
  };
  
  const title = field?.id.startsWith('field-new') ? "Add New Field" : "Edit Field";
  const conditionalFields = formFields.filter(f => f.id !== field.id && (f.type === 'select' || f.type === 'checkbox'));


  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-3xl">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>
            Configure the properties for this form field.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-6 py-4 max-h-[70vh] overflow-y-auto pr-4">
          <div className="space-y-2">
            <Label htmlFor="label">Field Label</Label>
            <Input id="label" value={currentField.label} onChange={(e) => handleChange('label', e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="type">Field Type</Label>
            <Select onValueChange={handleTypeChange} value={currentField.type}>
                <SelectTrigger id="type"><SelectValue /></SelectTrigger>
                <SelectContent>
                    {availableTypes.map(type => <SelectItem key={type} value={type} className="capitalize">{type.replace('_', ' ')}</SelectItem>)}
                </SelectContent>
            </Select>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox id="required" checked={currentField.required} onCheckedChange={(checked) => handleChange('required', checked as boolean)} />
            <Label htmlFor="required">This field is required</Label>
          </div>
          
          {(currentField.type === 'select' || currentField.type === 'checkbox') && (
            <>
                <Separator />
                <div className="space-y-4">
                    <div className="flex items-center justify-between">
                         <h4 className="font-semibold">Options</h4>
                         <Button variant="outline" size="sm" onClick={handleAddOption}>
                            <PlusCircle className="mr-2 h-4 w-4" /> Add Option
                         </Button>
                    </div>
                    <div className="space-y-2">
                        {currentField.options.map((option: string, index: number) => (
                            <div key={index} className="flex items-center gap-2">
                                <Input value={option} onChange={(e) => handleOptionChange(index, e.target.value)} />
                                <Button variant="ghost" size="icon" className="h-9 w-9 shrink-0 text-destructive" onClick={() => handleRemoveOption(index)}>
                                    <Trash2 className="h-4 w-4" />
                                </Button>
                            </div>
                        ))}
                    </div>
                </div>
            </>
          )}

          {currentField.type === 'field_group' && (
             <>
                <Separator />
                <div className="space-y-4">
                    <div className="flex items-center justify-between">
                         <h4 className="font-semibold">Sub-Fields for the Group</h4>
                         <Button variant="outline" size="sm" onClick={handleAddSubField}>
                            <PlusCircle className="mr-2 h-4 w-4" /> Add Sub-Field
                         </Button>
                    </div>
                    <div className="space-y-2">
                        {currentField.fields.map((subField: any, index: number) => (
                            <div key={index} className="flex items-center gap-2 p-2 border rounded-md bg-muted/25">
                               <GripVertical className="h-5 w-5 text-muted-foreground cursor-not-allowed" />
                               <div className="grid grid-cols-1 md:grid-cols-3 gap-2 flex-1">
                                    <Input placeholder="Label" value={subField.label} onChange={(e) => handleSubFieldChange(index, 'label', e.target.value)} />
                                    <Select value={subField.type} onValueChange={(value) => handleSubFieldChange(index, 'type', value)}>
                                        <SelectTrigger><SelectValue /></SelectTrigger>
                                        <SelectContent>
                                            {subFieldTypes.map(type => <SelectItem key={type} value={type} className="capitalize">{type}</SelectItem>)}
                                        </SelectContent>
                                    </Select>
                                     <div className="flex items-center space-x-2">
                                        <Checkbox id={`sub-req-${index}`} checked={subField.required} onCheckedChange={(checked) => handleSubFieldChange(index, 'required', checked)} />
                                        <Label htmlFor={`sub-req-${index}`} className="text-sm font-normal">Required</Label>
                                    </div>
                               </div>
                                <Button variant="ghost" size="icon" className="h-9 w-9 shrink-0 text-destructive" onClick={() => handleRemoveSubField(index)}>
                                    <Trash2 className="h-4 w-4" />
                                </Button>
                            </div>
                        ))}
                    </div>
                </div>
            </>
          )}

          <Separator />
          
          <div className="space-y-4">
            <h4 className="font-semibold">Conditional Logic</h4>
             <div className="flex items-center space-x-2">
                <Checkbox id="hasCondition" checked={hasCondition} onCheckedChange={(checked) => handleConditionToggle(!!checked)} />
                <Label htmlFor="hasCondition">Only show this field if a condition is met</Label>
            </div>
            {hasCondition && (
                <div className="p-4 border rounded-lg bg-muted/50 space-y-4">
                    <p className="text-sm">Show this field if the value of...</p>
                     <div className="grid grid-cols-1 md:grid-cols-3 gap-2 items-center">
                        <Select onValueChange={(value) => handleConditionChange('fieldId', value)} value={currentField.condition?.fieldId}>
                            <SelectTrigger><SelectValue placeholder="Select a field..." /></SelectTrigger>
                            <SelectContent>
                                {conditionalFields.map(f => <SelectItem key={f.id} value={f.id}>{f.label}</SelectItem>)}
                            </SelectContent>
                        </Select>
                         <Select defaultValue="equals" disabled>
                            <SelectTrigger><SelectValue/></SelectTrigger>
                            <SelectContent><SelectItem value="equals">is equal to</SelectItem></SelectContent>
                        </Select>
                        <Input placeholder="Enter value..." value={currentField.condition?.value} onChange={(e) => handleConditionChange('value', e.target.value)} />
                     </div>
                </div>
            )}
          </div>

        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSave}>Save Field</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
