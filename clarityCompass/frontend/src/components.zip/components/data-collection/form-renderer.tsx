
'use client';

import React, { useState, useEffect } from 'react';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Checkbox } from '../ui/checkbox';
import { Button } from '../ui/button';
import { useToast } from '@/hooks/use-toast';
import { Popover, PopoverContent, PopoverTrigger } from '../ui/popover';
import { CalendarIcon, PlusCircle, Trash2 } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { Calendar } from '../ui/calendar';
import { Separator } from '../ui/separator';

export function FormRenderer({ form, onSubmit }: { form: any, onSubmit: (data: any) => void }) {
    const [formData, setFormData] = useState<any>({});
    const [isSubmitting, setIsSubmitting] = useState(false);
    const { toast } = useToast();
    
    const initializeForm = () => {
        const initialData: { [key: string]: any } = {};
        form.fields.forEach((field: any) => {
            if (field.type === 'field_group') {
                initialData[field.id] = [];
            } else {
                 initialData[field.id] = field.defaultValue || undefined;
            }
        });
        setFormData(initialData);
    };

    useEffect(() => {
        initializeForm();
    }, [form]);

    const handleChange = (fieldId: string, value: any) => {
        setFormData((prev: any) => ({ ...prev, [fieldId]: value }));
    };

    const handleCheckboxChange = (fieldId: string, option: string, checked: boolean) => {
        const currentSelection = formData[fieldId] || [];
        let newSelection;
        if (checked) {
            newSelection = [...currentSelection, option];
        } else {
            newSelection = currentSelection.filter((item: string) => item !== option);
        }
        handleChange(fieldId, newSelection);
    };
    
    // Field Group Handlers
    const handleFieldGroupChange = (fieldId: string, groupIndex: number, subFieldId: string, value: any) => {
        const newGroupData = [...(formData[fieldId] || [])];
        if (!newGroupData[groupIndex]) {
            newGroupData[groupIndex] = {};
        }
        newGroupData[groupIndex][subFieldId] = value;
        handleChange(fieldId, newGroupData);
    };

    const addFieldGroupEntry = (fieldId: string, subFields: any[]) => {
        const newEntry = subFields.reduce((acc, subField) => {
            acc[subField.id] = '';
            return acc;
        }, {});
        const newGroupData = [...(formData[fieldId] || []), newEntry];
        handleChange(fieldId, newGroupData);
    };
    
    const removeFieldGroupEntry = (fieldId: string, groupIndex: number) => {
        const newGroupData = [...(formData[fieldId] || [])];
        newGroupData.splice(groupIndex, 1);
        handleChange(fieldId, newGroupData);
    }

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setIsSubmitting(true);
        
        onSubmit(formData);

        // Simulate API call
        setTimeout(() => {
            setIsSubmitting(false);
            initializeForm(); // Reset form state
            toast({
                title: "Submission Successful",
                description: `Your data for "${form.title}" has been saved.`,
            });
        }, 500);
    };
    
    const isFieldVisible = (field: any) => {
        if (!field.condition) {
            return true;
        }
        const { fieldId, operator, value } = field.condition;
        const sourceValue = formData[fieldId];
        
        if (operator === 'equals') {
            return sourceValue === value;
        }
        
        // Add other operators here in the future
        
        return true;
    }


    return (
        <form onSubmit={handleSubmit} className="space-y-8">
            {form.fields.map((field: any) => (
                 isFieldVisible(field) && (
                    <div key={field.id} className="space-y-2 animate-in fade-in duration-300">
                        <Label htmlFor={field.id} className="text-base">
                            {field.label}
                            {field.required && <span className="text-red-500 ml-1">*</span>}
                        </Label>
                        {(() => {
                            switch (field.type) {
                                case 'text':
                                    return <Input id={field.id} value={formData[field.id] || ''} onChange={(e) => handleChange(field.id, e.target.value)} required={field.required} />;
                                case 'textarea':
                                    return <Textarea id={field.id} value={formData[field.id] || ''} onChange={(e) => handleChange(field.id, e.target.value)} required={field.required} />;
                                case 'number':
                                    return <Input type="number" id={field.id} value={formData[field.id] || ''} onChange={(e) => handleChange(field.id, e.target.value)} required={field.required} />;
                                case 'select':
                                    return (
                                        <Select onValueChange={(value) => handleChange(field.id, value)} value={formData[field.id]} required={field.required}>
                                            <SelectTrigger id={field.id}><SelectValue placeholder={`Select a ${field.label.toLowerCase()}`} /></SelectTrigger>
                                            <SelectContent>
                                                {field.options.map((option: string) => <SelectItem key={option} value={option}>{option}</SelectItem>)}
                                            </SelectContent>
                                        </Select>
                                    );
                                case 'checkbox':
                                    return (
                                        <div className='space-y-2'>
                                            {field.options.map((option: string) => (
                                                <div key={option} className="flex items-center space-x-2">
                                                    <Checkbox id={`${field.id}-${option}`} onCheckedChange={(checked) => handleCheckboxChange(field.id, option, !!checked)} />
                                                    <Label htmlFor={`${field.id}-${option}`} className="font-normal">{option}</Label>
                                                </div>
                                            ))}
                                        </div>
                                    );
                                case 'date':
                                    return (
                                        <Popover>
                                            <PopoverTrigger asChild>
                                                <Button variant={"outline"} className={cn("w-full justify-start text-left font-normal", !formData[field.id] && "text-muted-foreground")}>
                                                    <CalendarIcon className="mr-2 h-4 w-4" />
                                                    {formData[field.id] ? format(new Date(formData[field.id]), "PPP") : <span>Pick a date</span>}
                                                </Button>
                                            </PopoverTrigger>
                                            <PopoverContent className="w-auto p-0">
                                                <Calendar mode="single" selected={formData[field.id] ? new Date(formData[field.id]) : undefined} onSelect={(date) => handleChange(field.id, date)} initialFocus />
                                            </PopoverContent>
                                        </Popover>
                                    );
                                case 'field_group':
                                    return (
                                        <div className="space-y-4 rounded-lg border p-4">
                                            {(formData[field.id] || []).map((group: any, index: number) => (
                                                <div key={index} className="space-y-4 p-4 rounded-md bg-muted/50 relative">
                                                    <Button variant="ghost" size="icon" className="absolute top-2 right-2 h-7 w-7 text-destructive" onClick={() => removeFieldGroupEntry(field.id, index)}>
                                                        <Trash2 className="h-4 w-4" />
                                                    </Button>
                                                    {field.fields.map((subField: any) => (
                                                        <div key={subField.id} className="grid items-center gap-2">
                                                            <Label htmlFor={`${field.id}-${index}-${subField.id}`}>
                                                                {subField.label}
                                                                {subField.required && <span className="text-red-500 ml-1">*</span>}
                                                            </Label>
                                                            <Input 
                                                                id={`${field.id}-${index}-${subField.id}`}
                                                                type={subField.type}
                                                                value={group[subField.id] || ''}
                                                                onChange={(e) => handleFieldGroupChange(field.id, index, subField.id, e.target.value)}
                                                                required={subField.required}
                                                             />
                                                        </div>
                                                    ))}
                                                    {index < formData[field.id].length -1 && <Separator />}
                                                </div>
                                            ))}
                                            <Button variant="outline" type="button" onClick={() => addFieldGroupEntry(field.id, field.fields)}>
                                                <PlusCircle className="mr-2 h-4 w-4" /> Add {field.label}
                                            </Button>
                                        </div>
                                    );
                                default:
                                    return <p>Unsupported field type</p>;
                            }
                        })()}
                    </div>
                )
            ))}
            <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? 'Submitting...' : 'Submit Data'}
            </Button>
        </form>
    );
}
