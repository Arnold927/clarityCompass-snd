

'use client';

import React, { useState, useEffect, useRef } from 'react';
import { initialDataForms, initialProjects, fieldTypes } from '@/lib/mock-data';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { GripVertical, PlusCircle, Save, Trash2, Check, ChevronsUpDown, Share2 } from 'lucide-react';
import { FieldEditor } from './field-editor';
import { Popover, PopoverContent, PopoverTrigger } from '../ui/popover';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '../ui/command';
import { cn } from '@/lib/utils';
import { Badge } from '../ui/badge';
import { useToast } from '@/hooks/use-toast';

export function FormBuilder({ formId }: { formId: string | null }) {
    const [form, setForm] = useState<any>(null);
    const [editingField, setEditingField] = useState<any>(null);
    const [isSaving, setIsSaving] = useState(false);
    const [open, setOpen] = useState(false);
    const { toast } = useToast();
    
    // State for drag and drop
    const [draggedField, setDraggedField] = useState<any>(null);

    useEffect(() => {
        if (formId) {
            const existingForm = initialDataForms.find(f => f.id === formId);
            setForm(existingForm ? { ...existingForm, projectIds: existingForm.projectIds || [] } : null);
        } else {
            setForm({
                title: '',
                description: '',
                projectIds: [],
                fields: []
            });
        }
    }, [formId]);

    const handleFormMetaChange = (field: string, value: string | string[]) => {
        setForm((prev: any) => ({ ...prev, [field]: value }));
    };

    const handleProjectSelect = (projectId: string) => {
        const currentProjectIds = form.projectIds || [];
        const newProjectIds = currentProjectIds.includes(projectId)
            ? currentProjectIds.filter((id: string) => id !== projectId)
            : [...currentProjectIds, projectId];
        handleFormMetaChange('projectIds', newProjectIds);
    };

    const handleAddField = () => {
        const newField = {
            id: `field-new-${Date.now()}`,
            label: 'New Field',
            type: 'text',
            required: false,
        };
        setEditingField(newField);
    };
    
    const handleEditField = (field: any) => {
        setEditingField(field);
    }

    const handleSaveField = (fieldToSave: any) => {
        setForm((prev: any) => {
            const existingFieldIndex = prev.fields.findIndex((f: any) => f.id === fieldToSave.id);
            if (existingFieldIndex > -1) {
                const updatedFields = [...prev.fields];
                updatedFields[existingFieldIndex] = fieldToSave;
                return { ...prev, fields: updatedFields };
            } else {
                return { ...prev, fields: [...prev.fields, fieldToSave] };
            }
        });
        setEditingField(null);
    };

    const handleDeleteField = (fieldId: string) => {
        setForm((prev: any) => ({
            ...prev,
            fields: prev.fields.filter((f: any) => f.id !== fieldId)
        }));
    };
    
    const handleSaveForm = () => {
        setIsSaving(true);
        // In a real app, you would send this to your backend API
        console.log('Saving form:', form);
        
        // Simulate API call and show toast
        setTimeout(() => {
            setIsSaving(false);
            toast({
                title: "Form Saved",
                description: `The form "${form.title}" has been saved successfully.`,
            });
        }, 500);
    };

    // Drag and Drop Handlers
    const handleDragStart = (e: React.DragEvent<HTMLDivElement>, field: any) => {
        setDraggedField(field);
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/html', e.currentTarget.outerHTML);
        e.currentTarget.style.opacity = '0.5';
    };

    const handleDragOver = (e: React.DragEvent<HTMLDivElement>, index: number) => {
        e.preventDefault();
        const draggedOverItem = e.currentTarget;
        if (draggedOverItem.classList.contains('drop-zone')) {
             draggedOverItem.classList.add('bg-secondary');
        }
    };
    
    const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
        e.currentTarget.classList.remove('bg-secondary');
    }

    const handleDrop = (e: React.DragEvent<HTMLDivElement>, dropIndex: number) => {
        e.preventDefault();
        e.currentTarget.classList.remove('bg-secondary');
        if (!draggedField) return;

        const fields = [...form.fields];
        const draggedIndex = fields.findIndex(f => f.id === draggedField.id);

        if (draggedIndex === -1) return;
        
        const [reorderedItem] = fields.splice(draggedIndex, 1);
        fields.splice(dropIndex, 0, reorderedItem);

        setForm({ ...form, fields });
        setDraggedField(null);
    };
    
    const handleDragEnd = (e: React.DragEvent<HTMLDivElement>) => {
        e.currentTarget.style.opacity = '1';
    };


    if (!form) {
        return <p>Loading form...</p>;
    }

    const selectedProjects = initialProjects.filter(p => form.projectIds.includes(p.id));

    return (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
            <div className="lg:col-span-2 space-y-6">
                <Card>
                    <CardHeader>
                        <CardTitle>Form Details</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="space-y-2">
                            <Label htmlFor="form-title">Form Title</Label>
                            <Input id="form-title" value={form.title} onChange={(e) => handleFormMetaChange('title', e.target.value)} />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="form-description">Description</Label>
                            <Textarea id="form-description" value={form.description} onChange={(e) => handleFormMetaChange('description', e.target.value)} />
                        </div>
                         <div className="space-y-2">
                            <Label>Link to Project(s)</Label>
                            <Popover open={open} onOpenChange={setOpen}>
                                <PopoverTrigger asChild>
                                    <Button variant="outline" role="combobox" aria-expanded={open} className="w-full justify-between h-auto">
                                        <div className="flex gap-1 flex-wrap">
                                            {selectedProjects.length > 0 ? selectedProjects.map(p => <Badge key={p.id} variant="secondary">{p.title}</Badge>) : "Select project(s)..."}
                                        </div>
                                        <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                                    </Button>
                                </PopoverTrigger>
                                <PopoverContent className="w-[--radix-popover-trigger-width] p-0">
                                    <Command>
                                        <CommandInput placeholder="Search projects..." />
                                        <CommandList>
                                            <CommandEmpty>No project found.</CommandEmpty>
                                            <CommandGroup>
                                                {initialProjects.map((project) => (
                                                <CommandItem
                                                    key={project.id}
                                                    value={project.title}
                                                    onSelect={() => handleProjectSelect(project.id)}
                                                >
                                                    <Check className={cn("mr-2 h-4 w-4", form.projectIds.includes(project.id) ? "opacity-100" : "opacity-0")}/>
                                                    {project.title}
                                                </CommandItem>
                                                ))}
                                            </CommandGroup>
                                        </CommandList>
                                    </Command>
                                </PopoverContent>
                            </Popover>
                        </div>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader>
                        <CardTitle>Form Fields</CardTitle>
                        <CardDescription>Drag and drop to reorder fields.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-4">
                            {form.fields.map((field: any, index: number) => (
                                <div 
                                    key={field.id} 
                                    className="drop-zone flex items-center gap-2 p-4 border rounded-lg bg-muted/50 transition-colors"
                                    draggable
                                    onDragStart={(e) => handleDragStart(e, field)}
                                    onDragOver={(e) => handleDragOver(e, index)}
                                    onDragLeave={handleDragLeave}
                                    onDrop={(e) => handleDrop(e, index)}
                                    onDragEnd={handleDragEnd}
                                >
                                    <GripVertical className="h-5 w-5 text-muted-foreground cursor-grab" />
                                    <div className="flex-1">
                                        <div className="flex items-center gap-2">
                                            {field.condition && <Share2 className="h-4 w-4 text-muted-foreground" title={`Conditional Field`} />}
                                            <p className="font-semibold">{field.label} {field.required && <span className="text-red-500">*</span>}</p>
                                        </div>
                                        <p className="text-sm text-muted-foreground capitalize">{field.type.replace('_', ' ')}</p>
                                    </div>
                                    <Button variant="outline" size="sm" onClick={() => handleEditField(field)}>Edit</Button>
                                    <Button variant="ghost" size="icon" className="h-8 w-8 text-red-500" onClick={() => handleDeleteField(field.id)}>
                                        <Trash2 className="h-4 w-4" />
                                    </Button>
                                </div>
                            ))}
                            {form.fields.length === 0 && <p className="text-center text-muted-foreground py-4">No fields added yet.</p>}
                        </div>
                    </CardContent>
                </Card>
            </div>
            <div className="lg:col-span-1 space-y-4 sticky top-4">
                <Card>
                    <CardHeader>
                        <CardTitle>Actions</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                         <Button className="w-full" onClick={handleAddField}>
                            <PlusCircle className="mr-2 h-4 w-4" /> Add New Field
                        </Button>
                        <Button className="w-full" variant="default" onClick={handleSaveForm} disabled={isSaving}>
                            <Save className="mr-2 h-4 w-4" /> {isSaving ? 'Saving...' : 'Save Form'}
                        </Button>
                    </CardContent>
                </Card>
            </div>

            {editingField && (
                <FieldEditor 
                    isOpen={!!editingField}
                    onClose={() => setEditingField(null)}
                    onSave={handleSaveField}
                    field={editingField}
                    formFields={form.fields}
                    availableTypes={fieldTypes}
                />
            )}
        </div>
    );
}
