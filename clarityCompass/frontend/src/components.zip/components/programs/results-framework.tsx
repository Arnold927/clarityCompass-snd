
'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableRow } from '@/components/ui/table';
import { PlusCircle, Edit, Trash2, ChevronDown, ChevronRight, Target, Link as LinkIcon } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { OutcomeEditor } from '@/components/strategic-plan/outcome-editor';
import { OutputEditor } from '@/components/strategic-plan/output-editor';
import { IndicatorEditor } from '@/components/strategic-plan/indicator-editor';
import { LinkObjectiveEditor } from './link-objective-editor';

export function ProgramResultsFramework({ program, setProgram, strategicObjectives }: { program: any, setProgram: Function, strategicObjectives: any[] }) {
    const [openObjectives, setOpenObjectives] = useState<string[]>(program.linkedObjectives.map((o: any) => o.number));
    const [openOutcomes, setOpenOutcomes] = useState<string[]>(program.linkedObjectives.flatMap((o: any) => o.outcomes?.map((out: any) => out.id) || []));

    const [editingOutcome, setEditingOutcome] = useState<any>(null);
    const [editingOutput, setEditingOutput] = useState<any>(null);
    const [editingIndicator, setEditingIndicator] = useState<{value: string, parent: any} | null>(null);

    const [isLinkerOpen, setIsLinkerOpen] = useState(false);
    const [parentObjective, setParentObjective] = useState<any>(null);
    const [parentOutcome, setParentOutcome] = useState<any>(null);
    const [parentForIndicator, setParentForIndicator] = useState<any>(null);

    const [deletingItem, setDeletingItem] = useState<any>(null);

    const toggleObjective = (id: string) => {
        setOpenObjectives(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
    };
    
    const toggleOutcome = (id: string) => {
        setOpenOutcomes(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
    };
    
    const handleLinkObjective = (objectiveToLink: any) => {
        const newLinkedObjective = {
            ...objectiveToLink,
            outcomes: [],
        };
        const updatedProgram = {
            ...program,
            linkedObjectives: [...program.linkedObjectives, newLinkedObjective]
        };
        setProgram(updatedProgram);
        setIsLinkerOpen(false);
    };

    const handleSaveOutcome = (outcomeToSave: any) => {
        const newOutcomes = [...(parentObjective.outcomes || [])];
        if (outcomeToSave.id) { // Editing
            const index = newOutcomes.findIndex(o => o.id === outcomeToSave.id);
            newOutcomes[index] = outcomeToSave;
        } else { // Adding
            newOutcomes.push({ ...outcomeToSave, id: `prog-outcome-${Date.now()}`, outputs: [], indicators: [] });
        }
        
        const updatedObjectives = program.linkedObjectives.map((so: any) => so.number === parentObjective.number ? { ...so, outcomes: newOutcomes } : so);
        setProgram({ ...program, linkedObjectives: updatedObjectives });
        
        setEditingOutcome(null);
        setParentObjective(null);
    };
    
    const handleSaveOutput = (outputToSave: any) => {
        const newOutputs = [...(parentOutcome.outputs || [])];
         if (outputToSave.id) { // Editing
            const index = newOutputs.findIndex(o => o.id === outputToSave.id);
            newOutputs[index] = outputToSave;
        } else { // Adding
            newOutputs.push({ ...outputToSave, id: `prog-output-${Date.now()}`, indicators: [] });
        }

        const updatedObjectives = program.linkedObjectives.map((so: any) => ({
            ...so,
            outcomes: so.outcomes.map((o: any) => o.id === parentOutcome.id ? { ...o, outputs: newOutputs } : o)
        }));
        setProgram({ ...program, linkedObjectives: updatedObjectives });
        
        setEditingOutput(null);
        setParentOutcome(null);
    };

    const handleSaveIndicator = (indicatorValue: string) => {
        if (!parentForIndicator && !editingIndicator) return;
        
        const { parent, type, index } = editingIndicator ? editingIndicator.parent : parentForIndicator;
        const isEditing = editingIndicator !== null;

        const updateIndicators = (indicators: any[]) => {
            const newIndicators = [...(indicators || [])];
            if (isEditing) {
                newIndicators[index] = { ...newIndicators[index], name: indicatorValue };
            } else {
                newIndicators.push({ name: indicatorValue, disaggregators: [] });
            }
            return newIndicators;
        };

        const updatedObjectives = program.linkedObjectives.map((so: any) => ({
            ...so,
            outcomes: so.outcomes.map((o: any) => {
                if (type === 'outcome' && o.id === parent.id) {
                    return { ...o, indicators: updateIndicators(o.indicators) }
                }
                if (type === 'output') {
                    return {
                        ...o,
                        outputs: o.outputs.map((op: any) => {
                            if (op.id === parent.id) {
                                return { ...op, indicators: updateIndicators(op.indicators) };
                            }
                            return op;
                        })
                    };
                }
                return o;
            })
        }));
        setProgram({ ...program, linkedObjectives: updatedObjectives });

        setEditingIndicator(null);
        setParentForIndicator(null);
    };
    
    const confirmDelete = () => {
        if (!deletingItem) return;
        
        const { type, id, parentId, grandParentId, index } = deletingItem;
        
        let updatedObjectives = [...program.linkedObjectives];

        if (type === 'objective') {
            updatedObjectives = updatedObjectives.filter(so => so.number !== id);
        } else if (type === 'outcome') {
            updatedObjectives = updatedObjectives.map(so => so.number === parentId ? { ...so, outcomes: so.outcomes.filter((o:any) => o.id !== id) } : so);
        } else if (type === 'output') {
            updatedObjectives = updatedObjectives.map(so => so.number === grandParentId ? { ...so, outcomes: so.outcomes.map((o:any) => o.id === parentId ? { ...o, outputs: o.outputs.filter((op:any) => op.id !== id)} : o) } : so);
        } else if (type === 'indicator') {
             updatedObjectives = updatedObjectives.map(so => ({
                ...so,
                outcomes: so.outcomes.map((o: any) => {
                    if (o.id === (deletingItem.indicatorType === 'outcome' ? parentId : grandParentId)) {
                        if (deletingItem.indicatorType === 'outcome') {
                            const newIndicators = [...o.indicators];
                            newIndicators.splice(index, 1);
                            return {...o, indicators: newIndicators};
                        }
                        return {
                            ...o,
                            outputs: o.outputs.map((op: any) => {
                                if (op.id === parentId) {
                                    const newIndicators = [...op.indicators];
                                    newIndicators.splice(index, 1);
                                    return { ...op, indicators: newIndicators };
                                }
                                return op;
                            })
                        };
                    }
                    return o;
                })
            }));
        }
        
        setProgram({ ...program, linkedObjectives: updatedObjectives });
        setDeletingItem(null);
    };

     const getIndicatorTitle = () => {
        if (!editingIndicator && !parentForIndicator) return "Add New Indicator";
        if (editingIndicator?.value) return "Edit Indicator";
        
        const { parent, type } = parentForIndicator || editingIndicator.parent;
        return `Add Indicator for ${type === 'outcome' ? 'Outcome' : 'Output'}: ${parent.name}`;
    }
    
    const unlinkedObjectives = strategicObjectives.filter(so => !program.linkedObjectives.some((lo:any) => lo.number === so.number));

    return (
       <>
            <div className="flex justify-end mb-4">
                <Button variant="outline" onClick={() => setIsLinkerOpen(true)} disabled={unlinkedObjectives.length === 0}>
                    <LinkIcon className="mr-2 h-4 w-4" /> Link Strategic Objective
                </Button>
            </div>
            <Table>
                <TableBody>
                    {program.linkedObjectives.map((objective: any) => (
                        <React.Fragment key={objective.number}>
                            <TableRow className="bg-muted/50 hover:bg-muted/50">
                                <TableCell colSpan={3} className="font-bold">
                                    <div className="flex items-center gap-2">
                                        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => toggleObjective(objective.number)}>
                                            {openObjectives.includes(objective.number) ? <ChevronDown className="h-5 w-5" /> : <ChevronRight className="h-5 w-5" />}
                                        </Button>
                                        <Target className="h-5 w-5 text-accent-foreground" />
                                        <Badge variant="secondary">{objective.number}</Badge>
                                        {objective.name}
                                    </div>
                                </TableCell>
                                <TableCell className="text-right">
                                     <Button variant="destructive" size="sm" onClick={() => setDeletingItem({ type: 'objective', name: objective.name, id: objective.number })}>
                                        <Trash2 className="mr-2 h-4 w-4" /> Unlink
                                    </Button>
                                </TableCell>
                            </TableRow>

                            {openObjectives.includes(objective.number) && (
                                <>
                                    {(objective.outcomes || []).map((outcome: any) => (
                                        <React.Fragment key={outcome.id}>
                                            <TableRow>
                                                <TableCell className="pl-16">
                                                     <div className="flex items-center gap-2">
                                                        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => toggleOutcome(outcome.id)}>
                                                            {openOutcomes.includes(outcome.id) ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                                                        </Button>
                                                        {outcome.name}
                                                    </div>
                                                </TableCell>
                                                <TableCell><Badge variant="outline">Outcome</Badge></TableCell>
                                                <TableCell>{outcome.indicators?.length || 0} indicators</TableCell>
                                                <TableCell className="text-right space-x-2">
                                                    <Button variant="outline" size="sm" onClick={() => { setParentObjective(objective); setEditingOutcome(outcome); }}>
                                                        <Edit className="mr-2 h-4 w-4" /> Edit
                                                    </Button>
                                                    <Button variant="destructive" size="sm" onClick={() => setDeletingItem({ type: 'outcome', name: outcome.name, id: outcome.id, parentId: objective.number })}>
                                                        <Trash2 className="mr-2 h-4 w-4" /> Delete
                                                    </Button>
                                                </TableCell>
                                            </TableRow>
                                            {openOutcomes.includes(outcome.id) && (
                                                <>
                                                    {(outcome.indicators || []).map((indicator: any, index: number) => (
                                                        <TableRow key={index}>
                                                            <TableCell className="pl-28 text-sm text-muted-foreground">{indicator.name}</TableCell>
                                                            <TableCell><Badge variant="ghost">Indicator</Badge></TableCell>
                                                            <TableCell></TableCell>
                                                            <TableCell className="text-right space-x-2">
                                                                <Button variant="ghost" size="sm" onClick={() => setEditingIndicator({value: indicator.name, parent: {parent: outcome, type: 'outcome', index}})}>Edit</Button>
                                                                <Button variant="ghost" size="sm" className="text-red-600" onClick={() => setDeletingItem({ type: 'indicator', indicatorType: 'outcome', name: indicator.name, index, parentId: outcome.id, grandParentId: null, greatGrandParentId: null })}>Delete</Button>
                                                            </TableCell>
                                                        </TableRow>
                                                    ))}
                                                    <TableRow>
                                                        <TableCell colSpan={4} className="pl-28 py-1">
                                                            <Button variant="ghost" size="sm" className="w-full justify-start text-muted-foreground" onClick={() => { setParentForIndicator({ parent: outcome, type: 'outcome' }); setEditingIndicator({value: '', parent: null}); }}>
                                                                <PlusCircle className="mr-2 h-4 w-4" /> Add Outcome Indicator
                                                            </Button>
                                                        </TableCell>
                                                    </TableRow>
                                                    {(outcome.outputs || []).map((output: any) => (
                                                        <React.Fragment key={output.id}>
                                                        <TableRow>
                                                            <TableCell className="pl-28">{output.name}</TableCell>
                                                            <TableCell><Badge variant="outline">Output</Badge></TableCell>
                                                            <TableCell>{output.indicators?.length || 0} indicators</TableCell>
                                                            <TableCell className="text-right space-x-2">
                                                                <Button variant="ghost" size="sm" onClick={() => { setParentOutcome(outcome); setEditingOutput(output); }}>Edit</Button>
                                                                <Button variant="ghost" size="sm" className="text-red-600" onClick={() => setDeletingItem({ type: 'output', name: output.name, id: output.id, parentId: outcome.id, grandParentId: objective.number })}>Delete</Button>
                                                            </TableCell>
                                                        </TableRow>
                                                            {(output.indicators || []).map((indicator: any, index: number) => (
                                                            <TableRow key={index}>
                                                                <TableCell className="pl-36 text-sm text-muted-foreground">{indicator.name}</TableCell>
                                                                <TableCell><Badge variant="ghost">Indicator</Badge></TableCell>
                                                                <TableCell></TableCell>
                                                                <TableCell className="text-right space-x-2">
                                                                    <Button variant="ghost" size="sm" onClick={() => setEditingIndicator({value: indicator.name, parent: {parent: output, type: 'output', index}})}>Edit</Button>
                                                                    <Button variant="ghost" size="sm" className="text-red-600" onClick={() => setDeletingItem({ type: 'indicator', indicatorType: 'output', name: indicator.name, index, parentId: output.id, grandParentId: outcome.id, greatGrandParentId: null })}>Delete</Button>
                                                                </TableCell>
                                                            </TableRow>
                                                            ))}
                                                            <TableRow>
                                                                <TableCell colSpan={4} className="pl-36 py-1">
                                                                    <Button variant="ghost" size="sm" className="w-full justify-start text-muted-foreground" onClick={() => { setParentForIndicator({ parent: output, type: 'output' }); setEditingIndicator({value: '', parent: null}); }}>
                                                                        <PlusCircle className="mr-2 h-4 w-4" /> Add Output Indicator
                                                                    </Button>
                                                                </TableCell>
                                                            </TableRow>
                                                        </React.Fragment>
                                                    ))}
                                                    <TableRow>
                                                        <TableCell colSpan={4} className="pl-28">
                                                            <Button variant="secondary" size="sm" onClick={() => { setParentOutcome(outcome); setEditingOutput({}); }}>
                                                                <PlusCircle className="mr-2 h-4 w-4" /> Add Output
                                                            </Button>
                                                        </TableCell>
                                                    </TableRow>
                                                </>
                                            )}
                                        </React.Fragment>
                                    ))}
                                    <TableRow>
                                        <TableCell colSpan={4} className="pl-16">
                                            <Button variant="outline" size="sm" onClick={() => { setParentObjective(objective); setEditingOutcome({}); }}>
                                                <PlusCircle className="mr-2 h-4 w-4" /> Add Outcome
                                            </Button>
                                        </TableCell>
                                    </TableRow>
                                </>
                            )}
                        </React.Fragment>
                    ))}
                </TableBody>
            </Table>
            {program.linkedObjectives.length === 0 && (
                <p className="text-center text-muted-foreground py-10">No strategic objectives have been linked to this program yet.</p>
            )}
            
            {isLinkerOpen && (
                <LinkObjectiveEditor
                    isOpen={isLinkerOpen}
                    onClose={() => setIsLinkerOpen(false)}
                    onLink={handleLinkObjective}
                    availableObjectives={unlinkedObjectives}
                />
            )}
             {editingOutcome && (
                <OutcomeEditor
                    outcome={editingOutcome}
                    isOpen={!!editingOutcome}
                    onClose={() => setEditingOutcome(null)}
                    onSave={handleSaveOutcome}
                />
            )}
            {editingOutput && (
                <OutputEditor
                    output={editingOutput}
                    isOpen={!!editingOutput}
                    onClose={() => setEditingOutput(null)}
                    onSave={handleSaveOutput}
                />
            )}
            {editingIndicator !== null && (
                <IndicatorEditor
                    indicator={editingIndicator.value}
                    isOpen={editingIndicator !== null}
                    onClose={() => {setEditingIndicator(null); setParentForIndicator(null);}}
                    onSave={handleSaveIndicator}
                    title={getIndicatorTitle()}
                />
            )}
            {deletingItem && (
                <AlertDialog open={!!deletingItem} onOpenChange={() => setDeletingItem(null)}>
                    <AlertDialogContent>
                        <AlertDialogHeader>
                            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                            <AlertDialogDescription>
                                This action cannot be undone. This will permanently delete the {deletingItem.type} "{deletingItem.name}" and all its children.
                            </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={confirmDelete} className="bg-destructive hover:bg-destructive/90">Delete</AlertDialogAction>
                        </AlertDialogFooter>
                    </AlertDialogContent>
                </AlertDialog>
            )}
       </>
    );
}
