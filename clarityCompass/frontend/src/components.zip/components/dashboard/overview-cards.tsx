import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { GanttChartSquare, Target, Users, CheckCircle } from "lucide-react";

const overviewData = [
  {
    title: "Active Projects",
    value: "12",
    icon: GanttChartSquare,
    description: "+5% from last month",
  },
  {
    title: "Success Rate",
    value: "92%",
    icon: Target,
    description: "+1.2% from last month",
  },
  {
    title: "Active Donors",
    value: "45",
    icon: Users,
    description: "+3 new this month",
  },
  {
    title: "Tasks Completed",
    value: "231",
    icon: CheckCircle,
    description: "34 pending",
  },
];

export function OverviewCards() {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {overviewData.map((item) => (
        <Card key={item.title}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{item.title}</CardTitle>
            <item.icon className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{item.value}</div>
            <p className="text-xs text-muted-foreground">{item.description}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
