
'use client';

import React from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { Button } from '../ui/button';
import { Edit, Trash2 } from 'lucide-react';
import type { Decision } from '@/lib/types';


interface AccountabilityLedgerProps {
    decisions: Decision[];
    onEdit?: (decision: Decision) => void;
    onDelete?: (decision: Decision) => void;
    isDashboard?: boolean;
}

export function AccountabilityLedger({ decisions, onEdit, onDelete, isDashboard = false }: AccountabilityLedgerProps) {

  const displayedDecisions = isDashboard ? decisions.slice(0, 5) : decisions;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Accountability Ledger</CardTitle>
        <CardDescription>Tracking key decisions and ownership.</CardDescription>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Decision</TableHead>
              <TableHead>Owner</TableHead>
              <TableHead>Deadline</TableHead>
              <TableHead>Status</TableHead>
              {!isDashboard && <TableHead className="text-right">Actions</TableHead>}
            </TableRow>
          </TableHeader>
          <TableBody>
            {displayedDecisions.map((item) => (
              <TableRow key={item.id}>
                <TableCell className="font-medium">{item.decision}</TableCell>
                <TableCell>{item.owner}</TableCell>
                <TableCell>{item.deadline}</TableCell>
                <TableCell>
                  <Badge
                    variant="outline"
                    className={cn(
                      item.status === "Completed" &&
                        "bg-green-100 text-green-800 border-green-200",
                      item.status === "In Progress" &&
                        "bg-blue-100 text-blue-800 border-blue-200",
                      item.status === "Overdue" &&
                        "bg-red-100 text-red-800 border-red-200"
                    )}
                  >
                    {item.status}
                  </Badge>
                </TableCell>
                {!isDashboard && (
                    <TableCell className="text-right space-x-2">
                        <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => onEdit?.(item)}>
                            <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="destructive" size="icon" className="h-8 w-8" onClick={() => onDelete?.(item)}>
                            <Trash2 className="h-4 w-4" />
                        </Button>
                    </TableCell>
                )}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
