

"use client";

import type { ReactNode } from "react";
import {
  BookCheck,
  BotMessageSquare,
  GanttChartSquare,
  LayoutDashboard,
  FileText,
  PanelLeft,
  Home,
  Briefcase,
  Database,
  Waypoints,
} from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Button } from "@/components/ui/button";
import {
  Sidebar,
  SidebarContent,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarProvider,
  SidebarInset,
  SidebarTrigger,
  SidebarFooter,
  SidebarSeparator,
} from "@/components/ui/sidebar";
import { cn } from "@/lib/utils";

const ngoMenuItems = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/strategic-plan", label: "Strategic Plan", icon: Waypoints },
  { href: "/programs", label: "Programs", icon: Briefcase },
  { href: "/projects", label: "Projects", icon: GanttChartSquare },
  { href: "/reports", label: "Reporting", icon: FileText },
  { href: "/accountability", label: "Accountability", icon: BookCheck },
  { href: "/data-collection", label: "Data Collection", icon: Database },
  { href: "/ai-reporter", label: "AI Reporter", icon: BotMessageSquare },
];

interface AppLayoutProps {
    children: ReactNode;
    platform?: 'ngo';
}

export default function AppLayout({ children, platform = 'ngo' }: AppLayoutProps) {
  const pathname = usePathname();
  
  const menuItems = ngoMenuItems;

  return (
    <SidebarProvider>
      <Sidebar>
        <SidebarHeader className="p-4">
            <div className="flex items-center gap-2">
                <Button variant="ghost" size="icon" className="md:hidden" asChild>
                    <SidebarTrigger><PanelLeft /></SidebarTrigger>
                </Button>
                <Link href="/" className="flex items-center gap-2 font-headline font-bold text-lg text-primary">
                    <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-6 w-6"
                    >
                    <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z" />
                    <path d="M12 16a4 4 0 1 0 0-8 4 4 0 0 0 0 8z" />
                    <path d="M12 12h.01" />
                    </svg>
                    <span>ClarityCompass NGO</span>
                </Link>
            </div>
        </SidebarHeader>
        <SidebarContent>
          <SidebarMenu>
            {menuItems.map((item) => (
              <SidebarMenuItem key={item.label}>
                <SidebarMenuButton
                  asChild
                  isActive={pathname === item.href}
                  className={cn(
                    "justify-start",
                     pathname === item.href && "bg-primary/10 text-primary"
                  )}
                  tooltip={item.label}
                >
                  <Link href={item.href}>
                    <item.icon className="h-4 w-4" />
                    <span>{item.label}</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
            ))}
          </SidebarMenu>
        </SidebarContent>
         <SidebarFooter>
          <SidebarSeparator />
           <SidebarMenu>
            <SidebarMenuItem>
                <SidebarMenuButton asChild className="justify-start">
                  <Link href="/">
                    <Home className="h-4 w-4" />
                    <span>Home</span>
                  </Link>
                </SidebarMenuButton>
            </SidebarMenuItem>
           </SidebarMenu>
        </SidebarFooter>
      </Sidebar>
      <SidebarInset>{children}</SidebarInset>
    </SidebarProvider>
  );
}
